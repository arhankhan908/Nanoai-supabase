# Nano AI — Floating API Key Panel and Encrypted Cloud Vault

## In-app use
1. Open the chat and type `give key`, `I want to give key`, `add Groq key`, or `add Mistral key`.
2. The floating key panel opens before the message is added to chat, so the prompt and key are not sent to the AI as a chat message.
3. Choose Groq or Mistral, paste one key or multiple keys separated by spaces/commas, and press **Save key**.
4. Nano AI uses the saved provider key and rotates through multiple keys when a rate limit is reached.

## Device storage vs cloud sync
- If the build has on-device accounts only (the default source configuration with `PASTE_SUPABASE_PROJECT_URL`), keys are saved on that device only. The panel states this explicitly.
- To enable cloud restore across devices, configure `SUPABASE_URL` and `SUPABASE_ANON_KEY` in `assets/config.js`, deploy the matching backend, and run the updated `backend/supabase.sql` in the Supabase SQL Editor.
- In the floating panel, enter a vault passphrase (at least 8 characters) before saving to sync. The app uses PBKDF2 (310,000 iterations, SHA-256) to derive an AES-256-GCM key. Only the encrypted payload is written to the `api_key_vault` table. The passphrase is not sent to Supabase and cannot be recovered.
- To restore on a different device, sign in with the same cloud account, type `give key`, select the provider, enter the same vault passphrase, and press **Restore from cloud**.
- The active-device provider key remains in the existing WebView `localStorage` for compatibility with Nano AI's current request path. Protect access to the device and avoid running untrusted scripts in the same app origin. For a public service, a backend proxy using server-side secrets is safer than client-held provider keys.

## Rate-limit cooldowns
Nano AI now reads Groq's `retry-after`, `x-ratelimit-reset-tokens`, and `x-ratelimit-reset-requests` headers where the WebView exposes them. It does not assume that every limit resets after exactly 60 seconds. Groq's limit windows vary by model and account, and a daily limit may take much longer than a per-minute limit.

## Validation
- `node --check` passed for `assets/app.js` and `assets/auth.js`.
- All inline JavaScript blocks in `nano-ai-single.html` passed `node --check`.
- Static assertions verified key-prompt interception, AES-GCM vault code, cloud-table adapters, and rate-limit header handling in both source and single-file versions.
- Android/AIDE build and on-device cloud sync were not run in this environment.
