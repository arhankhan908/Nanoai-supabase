// Live stream: say "open gmail", "give me@mail.com in gmail and give 1234 in password", "click next".
// Everything is parsed HERE on the phone. Nothing you type in a live command (passwords included) is sent to the AI.
window.Live = (() => {
  const B = () => window.NanoLive, wait = ms => new Promise(r => setTimeout(r, ms));
  let seq = 0; const pend = {}; let loadRes = null, isOpen = false;
  let frameSeq = 0; const framePend = {};
  const perf = { captureFps: 0, limitFps: 15, effectiveFps: 15, nativeDrops: 0, staleDrops: 0,
    nativeFrameAt: 0, captureState: "idle", analysisTimes: [], lastLatency: null, analyses: 0, failures: 0 };
  const _done = (id, v) => { pend[id]?.(v); delete pend[id] };
  const _frameReceived = (id, data, ts) => {
    const resolve = framePend[id]; if (!resolve) return;
    delete framePend[id];
    if (data && ts && Date.now() - ts <= 1600) resolve({ data, ts, age: Math.max(0, Date.now() - ts) });
    else { perf.staleDrops++; resolve(null); renderTelemetry(); }
  };
  const _nativeTelemetry = (captureFps, limitFps, effectiveFps, nativeDrops, frameAt, state) => {
    perf.captureFps = Number(captureFps) || 0; perf.limitFps = Number(limitFps) || 15;
    perf.effectiveFps = Number(effectiveFps) || 1; perf.nativeDrops = Number(nativeDrops) || 0;
    perf.nativeFrameAt = Number(frameAt) || 0; perf.captureState = String(state || "idle"); renderTelemetry();
  };
  function renderTelemetry() {
    const e = typeof document !== "undefined" && document.getElementById("lvt"); if (!e) return;
    const now = Date.now(), recent = perf.analysisTimes.filter(t => now - t <= 5000);
    const aiRate = recent.length / 5, age = perf.nativeFrameAt ? Math.max(0, now - perf.nativeFrameAt) + "ms" : "—";
    if (/unsupported|error|memory-pressure|paused|navigating|closed|destroyed/.test(perf.captureState)) {
      e.textContent = "Frames: " + perf.captureState + " · cap " + perf.captureFps + " fps (adaptive " + perf.effectiveFps + "/" + perf.limitFps + ") · AI " + aiRate.toFixed(1) + "/s · drop " + (perf.nativeDrops + perf.staleDrops);
    } else {
      e.textContent = "CAP " + perf.captureFps + " fps (adaptive " + perf.effectiveFps + "/" + perf.limitFps + ") · AI " + aiRate.toFixed(1) + "/s · age " + age + " · lat " + (perf.lastLatency == null ? "—" : Math.round(perf.lastLatency) + "ms") + " · drop " + (perf.nativeDrops + perf.staleDrops);
    }
  }
  function latestFrame() {
    if (!isOpen || !B() || typeof B().frame !== "function") return Promise.resolve(null);
    const id = ++frameSeq;
    return new Promise(resolve => {
      framePend[id] = resolve;
      setTimeout(() => { if (framePend[id]) { delete framePend[id]; perf.staleDrops++; resolve(null); renderTelemetry(); } }, 2200);
      try { B().frame(String(id)); } catch (e) { delete framePend[id]; perf.staleDrops++; resolve(null); renderTelemetry(); }
    });
  }
  function noteAnalysis(start, ok) {
    const now = Date.now(); perf.lastLatency = now - start; perf.analyses++;
    perf.analysisTimes.push(now); if (!ok) perf.failures++;
    perf.analysisTimes = perf.analysisTimes.filter(t => now - t <= 10000); renderTelemetry();
  }
  const _loaded = u => { const e = typeof document !== "undefined" && document.getElementById("lvu"); if (e && u) e.textContent = String(u).replace(/^https?:\/\//, "").slice(0, 40); loadRes?.(); loadRes = null };

  // ---- code that runs INSIDE the live page (stringified and sent over) ----
  const P = {
    securityState() {
      const text = (document.body && document.body.innerText || "").replace(/\s+/g, " ").slice(0, 12000);
      const url = String(location.href || "");
      if (/captcha|recaptcha|hcaptcha|verify you are human|confirm you are not a robot|security check|challenge-platform|cf-chl-/i.test(text + " " + url) ||
          document.querySelector('iframe[src*="captcha" i],iframe[src*="recaptcha" i],iframe[src*="hcaptcha" i], [id*="captcha" i], [class*="captcha" i]')) return "CAPTCHA / anti-bot check detected";
      if (/two[- ]step verification|two[- ]factor authentication|authenticator code|verification code|enter (the )?(one.time|security|verification) code|passkey|identity verification|additional verification|security key|verify your email address/i.test(text) ||
          document.querySelector('input[autocomplete="one-time-code" i],input[name*="otp" i],input[id*="otp" i]') ||
          /\/(challenge|checkpoint|verify|mfa)(\/|$)/i.test((new URL(url)).pathname)) return "Authentication/security challenge detected";
      return "OK";
    },
    state() {
      const text = (document.body && document.body.innerText || "").replace(/\s+/g, " ").slice(0, 1100);
      const controls = [...document.querySelectorAll("button,a,input,textarea,select,[role=button],[role=link],[role=textbox]")].slice(0, 60).map(e => {
        const type = (e.type === "password") ? "password" : (e.type || "");
        const label = type === "password" ? "" : (e.innerText || e.value || e.getAttribute("aria-label") || e.name || e.id || "");
        return [e.tagName, type, String(label).replace(/\s+/g, " ").slice(0, 50), e.getAttribute("aria-expanded") || "", e.getAttribute("aria-pressed") || "", e.disabled ? "disabled" : "", e.checked === true ? "checked" : ""].join(":");
      }).join("|");
      let frames = []; try { frames = [...document.querySelectorAll("iframe,frame")].map(f => { try { return {src:f.src || "", sameOrigin:!!(f.contentDocument && f.contentDocument.location.href), title:f.title || ""}; } catch (_) { return {src:f.src || "", sameOrigin:false, title:f.title || ""}; } }); } catch (_) {}
      return JSON.stringify({ url: location.href, title: document.title, text: text, controls: controls, count: document.querySelectorAll("button,a,input,textarea,select,[role=button],[role=link],[role=textbox]").length, frames: frames });
    },
    fill(kind, val, label) {
      const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== "hidden" && getComputedStyle(e).display !== "none" };
      // Search the main document, same-origin frames, and open shadow roots.
      // Cross-origin frames are intentionally not accessed; the browser's same-origin policy forbids it.
      let blockedFrame = false;
      const collect = (root, out = [], depth = 0) => {
        if (!root || depth > 6) return out;
        try {
          if (root.querySelectorAll) {
            for (const e of root.querySelectorAll('input,textarea,select,[role="textbox"],[contenteditable="true"],[aria-label],[placeholder]')) {
              if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.tagName) || e.getAttribute("role") === "textbox" || e.isContentEditable || e.hasAttribute("placeholder") || /user.?name|email|login|identifier/i.test((e.getAttribute("aria-label") || "") + " " + (e.id || "") + " " + (e.name || ""))) out.push(e);
              if (e.shadowRoot) collect(e.shadowRoot, out, depth + 1);
            }
            for (const f of root.querySelectorAll("iframe,frame")) {
              try { const d = f.contentDocument || f.contentWindow.document; if (d) collect(d, out, depth + 1); else blockedFrame = true; }
              catch (_) { blockedFrame = true; }
            }
          }
        } catch (_) {}
        return out;
      };
      const els = [...new Set(collect(document))].filter(e => vis(e) && !e.disabled && !e.readOnly && !["hidden", "submit", "button", "checkbox", "radio", "file", "image"].includes(String(e.type || "").toLowerCase()));
      const info = e => {
        let labels = ""; try { labels = e.labels ? [...e.labels].map(x => x.innerText || x.textContent || "").join(" ") : ""; } catch (_) {}
        let parent = ""; try { parent = e.parentElement ? e.parentElement.innerText || e.parentElement.textContent || "" : ""; } catch (_) {}
        return [e.name, e.id, e.autocomplete, e.placeholder, e.getAttribute("aria-label"), e.getAttribute("data-testid"), labels, parent].join(" ").replace(/\s+/g, " ").slice(0, 500);
      };
      const scoreId = e => {
        const q = info(e).toLowerCase(); let n = 0;
        if (/username|user name|user_name|login name|nickname/.test(q)) n += 12;
        if (/autocomplete[^ ]* username|username/.test(String(e.autocomplete || "").toLowerCase())) n += 15;
        if (/email|identifier|account/.test(q)) n += 5;
        if (/password|passcode|otp|verification|search/.test(q)) n -= 30;
        if (e.type === "password") n -= 100;
        if (e.type === "email") n += 4;
        if (e.type === "text" || e.getAttribute("role") === "textbox" || e.isContentEditable) n += 1;
        return n;
      };
      let el;
      if (kind === "password") el = els.find(e => e.type === "password" || e.autocomplete === "current-password");
      else if (kind === "id") {
        const ranked = els.map(e => ({ e, score: scoreId(e) })).sort((a,b) => b.score-a.score);
        el = ranked.length && ranked[0].score > 0 ? ranked[0].e : null;
      } else if (kind === "search") el = els.find(e => e.type === "search" || /search|(^|\s)q(\s|$)/i.test(info(e))) || els.find(e => e.type === "text");
      else { const l = label.toLowerCase(); el = els.find(e => info(e).toLowerCase().includes(l)) }
      if (!el) return blockedFrame ? "CROSSORIGIN_FRAME" : "NOFIELD";
      el.scrollIntoView({ block: "center" }); const _o = el.style.outline; el.style.outline = "3px solid #E5484D"; setTimeout(() => el.style.outline = _o, 1400);
      el.focus();
      if (el.isContentEditable) { el.textContent = val; }
      else if (el.tagName === "TEXTAREA") { Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set.call(el, val); }
      else if (el.tagName === "INPUT") { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, val); }
      else if (el.tagName === "SELECT") { const opt = [...el.options].find(o => o.text.toLowerCase() === String(val).toLowerCase() || o.value.toLowerCase() === String(val).toLowerCase()); if (opt) el.value = opt.value; else return "NOFIELD"; }
      try { el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: String(val) })); } catch (_) { el.dispatchEvent(new Event("input", { bubbles: true })); }
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return "OK";
    },
    click(text) {
      const vis = e => { try { const r=e.getBoundingClientRect(), c=getComputedStyle(e); return r.width>0 && r.height>0 && c.visibility!=='hidden' && c.display!=='none' && !e.disabled; } catch(_) { return false; } };
      let blockedFrame=false; const roots=[];
      const walk=(root,depth=0)=>{ if(!root||depth>6||roots.includes(root))return; roots.push(root); try { if(root.querySelectorAll){ for(const e of root.querySelectorAll('*')) if(e.shadowRoot) walk(e.shadowRoot,depth+1); for(const f of root.querySelectorAll('iframe,frame')) { try { const d=f.contentDocument||f.contentWindow.document; if(d)walk(d,depth+1); else blockedFrame=true; } catch(_){blockedFrame=true;} } } }catch(_){} };
      walk(document); const all=[]; for(const root of roots) try { all.push(...root.querySelectorAll('button,a,input,textarea,select,[role=button],[role=link],[role=menuitem],[role=tab],[role=option],[onclick],[tabindex],summary,label,[data-testid]')); } catch(_){}
      const unique=[...new Set(all)].filter(vis), tx=e=>String(e.innerText||e.value||e.getAttribute('aria-label')||e.title||e.getAttribute('data-testid')||e.name||'').replace(/\s+/g,' ').trim();
      const norm=x=>String(x||'').toLowerCase().replace(/[’']/g,'').replace(/[^\p{L}\p{N}@._-]+/gu,' ').trim(), t=norm(text);
      const score=e=>{const label=norm(tx(e)),tag=e.tagName.toLowerCase();let n=0;if(label===t)n+=100;else if(t&&label.includes(t))n+=55;else if(t&&t.split(' ').every(w=>label.includes(w)))n+=25;if(['button','a','summary'].includes(tag))n+=12;if(e.getAttribute('role'))n+=8;if(e.hasAttribute('onclick'))n+=8;if(e.getAttribute('aria-disabled')==='true'||e.disabled)n-=100;if(e.type==='password')n-=100;if(!label)n-=8;return n;};
      let el=null;if(t){const ranked=unique.map(e=>({e,n:score(e)})).sort((a,b)=>b.n-a.n);if(ranked[0]&&ranked[0].n>=25)el=ranked[0].e;}
      if(!el&&(!t||/^(submit|go|continue|login|log in|sign in|next)$/.test(t)))el=unique.find(e=>e.type==='submit'||e.getAttribute('type')==='submit');
      if(!el)return blockedFrame?'CROSSORIGIN_FRAME: target may be inside a cross-origin frame; browser security prevents page-script access':'NOTFOUND';
      if(el.getAttribute('aria-disabled')==='true'||el.disabled)return 'DISABLED:'+(tx(el)||'target');
      try{el.scrollIntoView({block:'center',inline:'center',behavior:'instant'});}catch(_){el.scrollIntoView();}
      const r=el.getBoundingClientRect(),x=Math.round(r.left+r.width/2),y=Math.round(r.top+r.height/2),root=el.ownerDocument;
      try{const old=root.getElementById('nano-live-click-marker');if(old)old.remove();const mark=root.createElement('div');mark.id='nano-live-click-marker';mark.style.cssText='position:fixed;left:'+x+'px;top:'+y+'px;width:30px;height:30px;transform:translate(-50%,-50%);border:3px solid #00E5FF;border-radius:50%;box-shadow:0 0 0 5px rgba(0,229,255,.22),0 0 14px #00E5FF;z-index:2147483647;pointer-events:none;box-sizing:border-box';const dot=root.createElement('div');dot.style.cssText='position:absolute;left:50%;top:50%;width:6px;height:6px;transform:translate(-50%,-50%);background:#FF3B70;border-radius:50%';mark.appendChild(dot);root.documentElement.appendChild(mark);setTimeout(()=>mark.remove(),1600);}catch(_){}
      const label=(tx(el)||el.tagName.toLowerCase()).slice(0,60);try{el.focus({preventScroll:true});}catch(_){}try{el.click();}catch(e){return 'CLICK_ERROR:'+(e&&e.message||'element click failed');}return 'ATTEMPTED:'+label+'@'+x+','+y;
    },
    observe() {
      const roots=[];let crossOriginFrames=0;const walk=(root,depth=0)=>{if(!root||depth>6||roots.includes(root))return;roots.push(root);try{if(root.querySelectorAll){for(const e of root.querySelectorAll('*'))if(e.shadowRoot)walk(e.shadowRoot,depth+1);for(const f of root.querySelectorAll('iframe,frame')){try{const d=f.contentDocument||f.contentWindow.document;if(d)walk(d,depth+1);else crossOriginFrames++;}catch(_){crossOriginFrames++;}}}}catch(_){}};
      walk(document);const vis=e=>{try{const r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>2&&r.height>2&&c.visibility!=='hidden'&&c.display!=='none'&&r.bottom>0&&r.top<innerHeight*1.5&&!e.disabled;}catch(_){return false;}};
      const candidates=[];for(const root of roots)try{candidates.push(...root.querySelectorAll('a[href],button,input,textarea,select,[role=button],[role=link],[role=menuitem],[role=tab],[role=option],[onclick],[tabindex],summary,label,[contenteditable=true]'));}catch(_){}
      for(const root of roots)try{root.querySelectorAll('[data-nano-i]').forEach(e=>e.removeAttribute('data-nano-i'));}catch(_){}const els=[...new Set(candidates)].filter(vis).slice(0,90);
      const lines=els.map((e,k)=>{const id=k+1;try{e.setAttribute('data-nano-i',id);}catch(_){}const tag=e.tagName.toLowerCase(),ty=tag==='input'?'['+e.type+']':'',t=String(e.innerText||e.value||e.getAttribute('aria-label')||e.title||e.getAttribute('data-testid')||'').trim().replace(/\s+/g,' ').slice(0,55),ph=String(e.placeholder||e.getAttribute('aria-label')||e.name||e.getAttribute('data-testid')||'').slice(0,35),val=tag==='input'&&e.type!=='password'&&e.value?' ='+e.value.slice(0,20):'';return id+' '+tag+ty+' "'+t+'"'+(ph&&ph!==t?' ('+ph+')':'')+val;});
      return 'URL: '+location.href.slice(0,150)+'\nTITLE: '+document.title.slice(0,80)+'\nTEXT: '+(document.body.innerText||'').replace(/\s+/g,' ').slice(0,650)+'\nELEMENTS (index can be clicked):\n'+lines.join('\n')+(crossOriginFrames?'\nNOTE: '+crossOriginFrames+' cross-origin frame(s) are not inspectable from page JavaScript.':'');
    },
    fillIdx(i, val) {
      const roots=[]; const walk=(root,depth=0)=>{if(!root||depth>6||roots.includes(root))return;roots.push(root);try{if(root.querySelectorAll){for(const e of root.querySelectorAll('*'))if(e.shadowRoot)walk(e.shadowRoot,depth+1);for(const f of root.querySelectorAll('iframe,frame'))try{const d=f.contentDocument||f.contentWindow.document;if(d)walk(d,depth+1);}catch(_){}}}catch(_){}}; walk(document); let el=null; for(const root of roots){try{el=root.querySelector('[data-nano-i="'+i+'"]');if(el)break;}catch(_){}} if (!el) return "NOEL";
      el.scrollIntoView({ block: "center" }); const _o = el.style.outline; el.style.outline = "3px solid #E5484D"; setTimeout(() => el.style.outline = _o, 1400); el.focus();
      if (el.isContentEditable) el.textContent = val; else { const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(proto, "value").set.call(el, val) }
      el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true }));
      return "OK:" + (el.placeholder || el.getAttribute("aria-label") || el.name || el.type || "field");
    },
    clickIdx(i) {
      const idx=String(Number(i)),roots=[];const walk=(root,depth=0)=>{if(!root||depth>6||roots.includes(root))return;roots.push(root);try{if(root.querySelectorAll){for(const e of root.querySelectorAll('*'))if(e.shadowRoot)walk(e.shadowRoot,depth+1);for(const f of root.querySelectorAll('iframe,frame'))try{const d=f.contentDocument||f.contentWindow.document;if(d)walk(d,depth+1);}catch(_){}}}catch(_){}};walk(document);
      let el=null;for(const root of roots){try{el=root.querySelector('[data-nano-i="'+idx+'"]');if(el)break;}catch(_){}}if(!el)return 'NOEL';if(el.disabled||el.getAttribute('aria-disabled')==='true')return 'DISABLED:'+(el.innerText||el.value||'target');
      try{el.scrollIntoView({block:'center',inline:'center',behavior:'instant'});}catch(_){el.scrollIntoView();}const r=el.getBoundingClientRect(),x=Math.round(r.left+r.width/2),y=Math.round(r.top+r.height/2),doc=el.ownerDocument;
      try{const old=doc.getElementById('nano-live-click-marker');if(old)old.remove();const mark=doc.createElement('div');mark.id='nano-live-click-marker';mark.style.cssText='position:fixed;left:'+x+'px;top:'+y+'px;width:30px;height:30px;transform:translate(-50%,-50%);border:3px solid #00E5FF;border-radius:50%;box-shadow:0 0 0 5px rgba(0,229,255,.22),0 0 14px #00E5FF;z-index:2147483647;pointer-events:none;box-sizing:border-box';doc.documentElement.appendChild(mark);setTimeout(()=>mark.remove(),1600);}catch(_){}
      const label=String(el.innerText||el.value||el.getAttribute('aria-label')||el.title||el.tagName.toLowerCase()).trim().replace(/\s+/g,' ').slice(0,60);try{el.focus({preventScroll:true});}catch(_){}try{el.click();}catch(e){return 'CLICK_ERROR:'+(e&&e.message||'element click failed');}return 'ATTEMPTED:'+label+'@'+x+','+y;
    },
    enter() {
      const a = document.activeElement; if (!a) return "NOFOCUS";
      if (a.form) { try { a.form.requestSubmit() } catch (e) { a.form.submit() } return "OK" }
      ["keydown", "keypress", "keyup"].forEach(t => a.dispatchEvent(new KeyboardEvent(t, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true })));
      return "OK";
    },
    scroll(dir) { window.scrollBy({ top: (dir === "up" ? -1 : 1) * innerHeight * .8, behavior: "smooth" }); return "OK" },
    read() { return (document.title + "\n" + (document.body.innerText || "")).replace(/\n{3,}/g, "\n\n").slice(0, 1800) }
  };
  const run = (fn, ...args) => new Promise(res => {
    const id = ++seq; pend[id] = res; setTimeout(() => { if (pend[id]) { delete pend[id]; res("TIMEOUT") } }, 8000);
    B().run(String(id), `(${fn})(${args.map(a => JSON.stringify(a)).join(",")})`);
  });

  // ---- command parsing ----
  const SITES = { gmail: "https://mail.google.com", grail: "https://mail.google.com", google: "https://www.google.com", youtube: "https://www.youtube.com", github: "https://github.com", instagram: "https://www.instagram.com", facebook: "https://www.facebook.com", twitter: "https://x.com", x: "https://x.com", reddit: "https://www.reddit.com", discord: "https://discord.com/app", netflix: "https://www.netflix.com", amazon: "https://www.amazon.com", wikipedia: "https://www.wikipedia.org", outlook: "https://outlook.live.com", yahoo: "https://mail.yahoo.com" };
  const toUrl = t => { t = t.trim().replace(/^["']|["']$/g, ""); const k = t.toLowerCase().replace(/\s+/g, ""); if (SITES[k]) return SITES[k];
    if (/^https?:\/\//i.test(t)) return t; if (/^[^\s]+\.[a-z]{2,}([\/?#]\S*)?$/i.test(t)) return "https://" + t;
    return "https://www.google.com/search?q=" + encodeURIComponent(t) };
  const kindOf = f => { f = f.toLowerCase().replace(/\b(the|box|field|bar|filed|feild)\b/g, "").trim();
    if (/^(password|pass|pw|passcode|passwd)$/.test(f)) return ["password"];
    if (/^(gmail|grail|email|e-mail|mail|username|user|user name|login|id|phone|number|identifier|account)$/.test(f)) return ["id"];
    if (/^(search|query|find)$/.test(f)) return ["search"];
    return ["label", f] };
  const FILL = /^(?:give|put|type|enter|write|fill|set|insert|add)\s+(?:me\s+)?(.+?)\s+(?:in|into|on|as|for|to)\s+(?:the\s+)?(.+)$/i;
  const SPLIT = /\s*(?:,|;|\band\b|\bthen\b)\s+(?=(?:give|put|type|enter|write|fill|set|insert|add|click|press|tap|hit|submit|scroll|go|open|read|close|back|reload)\b)/i;

  function parse(text) {
    const segs = text.trim().split(SPLIT).map(s => s.trim()).filter(Boolean), steps = [];
    for (const s of segs) {
      let m;
      if (/^(?:(?:enable|turn on|switch to|use)\s+)?(?:the\s+)?desktop(?:\s+site|\s+mode|\s+view)?$/i.test(s)) steps.push({ t: "desktop", v: true });
      else if (/^(?:(?:disable|turn off|switch back to|use)\s+)?(?:the\s+)?mobile(?:\s+site|\s+view)?$/i.test(s)) steps.push({ t: "desktop", v: false });
      else if (/^(?:full ?screen|maximize live|expand live)(?:\s*(?:stream|view))?$/i.test(s)) steps.push({ t: "fullscreen", v: true });
      else if (/^(?:exit|leave|close) full ?screen$/i.test(s)) steps.push({ t: "fullscreen", v: false });
      else if (/^(?:go|start|begin)\s+live(?:\s*(?:stream|view))?$/i.test(s)) steps.push({ t: "golive" });
      else if ((m = s.match(/^(?:open|launch|visit|go to|goto|load|start)\s+(?:the\s+)?(?:live\s*(?:stream|view)?\s*(?:of|with|on)?\s*)?(.+)$/i)) && !/^(live|stream)$/i.test(m[1]) && m[1].trim().split(/\s+/).length <= 2) steps.push({ t: "open", v: toUrl(m[1]) });
      else if (/^(?:open|start|show)\s+(?:the\s+)?live(?:\s*(?:stream|view))?$/i.test(s)) steps.push({ t: "open", v: "https://www.google.com" });
      else if ((m = s.match(FILL))) { const val = m[1].trim().replace(/^["'“”]|["'“”]$/g, ""), k = kindOf(m[2]); steps.push({ t: "fill", v: val, k: k[0], l: k[1] || "", f: m[2].trim() }) }
      else if ((m = s.match(/^(?:click|press|tap|hit|select)\s+(?:on\s+)?(?:the\s+)?(.*?)(?:\s+button)?$/i))) { const w = m[1].trim(); if (/^(enter|return)$/i.test(w)) steps.push({ t: "enter" }); else steps.push({ t: "click", v: w }) }
      else if (/^submit$/i.test(s)) steps.push({ t: "click", v: "" });
      else if ((m = s.match(/^scroll\s*(up|down)?$/i))) steps.push({ t: "scroll", v: (m[1] || "down").toLowerCase() });
      else if (/^(?:go\s+)?back$/i.test(s)) steps.push({ t: "back" });
      else if (/^(?:reload|refresh)$/i.test(s)) steps.push({ t: "reload" });
      else if (/^(?:read|what(?:'s| is) on)\s*(?:the\s+)?(?:page|screen)?$|^what do you see$/i.test(s)) steps.push({ t: "read" });
      else if (/^(?:close|stop|end|hide|exit)\s*(?:the\s+)?(?:live(?:\s*(?:stream|view))?|browser|stream)?$/i.test(s)) steps.push({ t: "close" });
      else return null;   // anything we don't recognise goes to the AI as normal chat
    }
    return steps.length ? steps : null;
  }

  // ---- runner: runs steps one by one, shows each in the live HUD, can pause / stop, and saves runs ----
  const R = { active: false, paused: false, stop: false, delay: 700 };
  let frac = 0.45;
  let desktopEnabled = false;
  const $$ = id => typeof document !== "undefined" ? document.getElementById(id) : null;
  const hud = t => { const h = $$("lvh"), p = $$("lvp"); if (h) h.textContent = t; if (p) p.textContent = R.paused ? "▶" : "⏸" };
  const liveShow = () => { B().show(frac); const b = $$("livebar"); if (b) b.hidden = false; isOpen = true };
  const liveGo = url => { liveShow(); url ? B().open(url) : B().blank(); const u = $$("lvu"); if (u) u.textContent = url ? url.replace(/^https?:\/\//, "").slice(0, 40) : "live" };
  const cancelPendingFrames = () => { Object.keys(framePend).forEach(k => { const resolve = framePend[k]; delete framePend[k]; resolve(null); }); };
  const liveClose = () => { if (R.active) { R.stop = true; R.paused = false; } cancelPendingFrames(); try { B().close() } catch (e) {} const b = $$("livebar"); if (b) b.hidden = true; isOpen = false };
  const _closed = () => { if (R.active) { R.stop = true; R.paused = false; } cancelPendingFrames(); const b = $$("livebar"); if (b) b.hidden = true; isOpen = false };
  const _nativePaused = () => { if (R.active) { R.stop = true; R.paused = false; } cancelPendingFrames(); perf.captureState = "paused"; renderTelemetry(); };
  const _size = () => { frac = frac < 0.6 ? 1.0 : 0.45; B().show(frac); const b = $$("lvx"); if (b) b.title = frac > 0.8 ? "Exit full screen" : "Enter full screen" };
  const _desktopChanged = enabled => { desktopEnabled = !!enabled; const h = $$("lvh"); if (h) h.textContent = enabled ? "Desktop site enabled · reloaded" : "Mobile site enabled · reloaded"; const d = $$("lvd"); if (d) { d.classList.toggle("on", desktopEnabled); d.textContent = desktopEnabled ? "Desktop ✓" : "Desktop"; } };
  const toggleDesktop = () => { desktopEnabled = !desktopEnabled; try { if (B() && B().desktop) B().desktop(desktopEnabled); else { desktopEnabled = !desktopEnabled; return; } _desktopChanged(desktopEnabled); } catch (e) { _desktopChanged(!desktopEnabled); } };
  if (typeof window !== "undefined" && typeof document !== "undefined") window.addEventListener("load", () => { const on = (id, f) => { const e = $$(id); if (e) e.onclick = f };
    on("lvp", () => _ctl("toggle")); on("lvs", () => _ctl("stop")); on("lvx", _size); on("lvd", toggleDesktop); on("lvc", liveClose) });
  const label = s => {
    if (s.t === "fullscreen") return s.v ? "entering full screen" : "exiting full screen";
    if (s.t === "desktop") return s.v ? "enabling desktop site" : "switching to mobile site";
    if (s.t === "golive") return "going live";
    if (s.t === "open") return "opening " + String(s.v || "").replace(/^https?:\/\//, "").split("/")[0];
    if (s.t === "fill") return "typing in " + s.f + (s.k === "password" ? " (hidden)" : "");
    if (s.t === "click") return "clicking " + (s.v || "submit");
    if (s.t === "enter") return "pressing Enter";
    if (s.t === "scroll") return "scrolling " + s.v;
    if (s.t === "back") return "going back";
    if (s.t === "reload") return "reloading";
    if (s.t === "read") return "reading the page";
    if (s.t === "close") return "closing";
    return s.t;
  };
  const _ctl = c => { if (!R.active) { if (c === "stop") hud("Stopped"); return }
    if (c === "toggle") R.paused = !R.paused; else if (c === "pause") R.paused = true; else if (c === "resume") R.paused = false; else if (c === "stop") { R.stop = true; R.paused = false }
    hud(R.stop ? "Stopping…" : R.paused ? "Paused" : "Running") };
  const RUNS = () => { try { return JSON.parse(localStorage.getItem("nano_runs") || "{}") } catch (e) { return {} } };
  let last = [];

  async function exec(steps, act) {
    const out = []; R.active = true; R.paused = false; R.stop = false;
    try {
      for (let i = 0; i < steps.length; i++) {
        while (R.paused && !R.stop) await wait(200);
        if (R.stop) { out.push("■ Stopped after step " + i + " of " + steps.length); break }
        const s = steps[i]; hud("Step " + (i + 1) + "/" + steps.length + ": " + label(s)); act.step(label(s)[0].toUpperCase() + label(s).slice(1));
        if (["fill", "click", "enter", "scroll", "read"].includes(s.t) && isOpen) {
          const security = await run(P.securityState);
          if (security && security !== "OK") { out.push("⛔ Stopped: " + security + ". Complete the check manually in the visible browser, then give a new command."); break; }
        }
        if (s.t === "desktop") {
          try { if (B() && typeof B().desktop === "function") { desktopEnabled = !!s.v; B().desktop(desktopEnabled); _desktopChanged(desktopEnabled); out.push(s.v ? "▣ Desktop site enabled. The live page is reloading with a desktop user agent." : "▣ Mobile site enabled. The live page is reloading with a mobile user agent."); } else out.push("⚠ Desktop-site control is unavailable in this build."); }
          catch (e) { out.push("⚠ Could not change site mode: " + String(e.message || e)); }
        }
        else if (s.t === "fullscreen") {
          frac = s.v ? 1.0 : 0.45;
          try { B().show(frac); const b = $$("lvx"); if (b) { b.title = s.v ? "Exit full screen" : "Enter full screen"; b.setAttribute("aria-label", b.title); } out.push(s.v ? "⛶ Live browser expanded to full screen. Tap once to reveal controls." : "Live browser returned to split view."); }
          catch (e) { out.push("⚠ Could not change live view size: " + String(e.message || e)); }
        }
        else if (s.t === "golive") { liveGo("https://bot.nebulanetwork.club/"); await Promise.race([new Promise(r => loadRes = r), wait(12000)]); await wait(300); out.push("● Opened **bot.nebulanetwork.club**. Say `open ...` to navigate elsewhere.") }
        else if (s.t === "open") { liveGo(s.v); await Promise.race([new Promise(r => loadRes = r), wait(12000)]); await wait(600); out.push("● Opened **" + s.v.replace(/^https?:\/\//, "").split("/")[0] + "**") }
        else if (s.t === "fill") { const r = await run(P.fill, s.k, s.v, s.l); out.push(r === "OK" ? "✓ Filled **" + s.f + "**" + (s.k === "password" ? " (hidden)" : "") : r === "CROSSORIGIN_FRAME" ? "⚠ The username field is inside a cross-origin frame that this WebView cannot access. Open the page directly or tap the field manually; Nano AI will not bypass the browser security boundary." : "⚠ Couldn’t find an editable **" + s.f + "** field in the live page. No text was entered.") }
        else if (s.t === "click") { const r = await clickAndVerify(P.click, s.v); out.push(r); }
        else if (s.t === "enter") { const r = await run(P.enter); out.push(r === "OK" ? "✓ Pressed Enter" : "⚠ Nothing selected to press Enter on"); await wait(900) }
        else if (s.t === "scroll") { await run(P.scroll, s.v); out.push("✓ Scrolled " + s.v) }
        else if (s.t === "back") { B().nav("back"); out.push("✓ Went back"); await wait(800) }
        else if (s.t === "reload") { B().nav("reload"); out.push("✓ Reloaded"); await wait(800) }
        else if (s.t === "read") { const r = await run(P.read); out.push("**On screen:**\n\n" + String(r).slice(0, 1500)) }
        else if (s.t === "close") { liveClose(); out.push("Live stream closed.") }
        if (i < steps.length - 1) await wait(R.delay);   // pause between steps so you can watch
      }
    } finally { R.active = false; if (isOpen) hud(R.stop ? "Stopped" : "Done. Waiting for commands") }
    return out;
  }


  // ---- AI agent: you say what you want in plain words; it looks at the page, then clicks and types by itself ----
  const SYS = 'You control the real web browser visible to the user. Each turn includes accessible DOM/text and may include a current screenshot. Use screenshot evidence only when an image is actually supplied; otherwise rely on DOM/text and do not guess invisible controls. Reply ONLY as JSON: {"say":"short status","actions":[...],"done":false}. Actions: {"do":"open","url":"https://..."} {"do":"type","i":3,"text":"..."} {"do":"click","i":5} {"do":"enter"} {"do":"scroll","dir":"down"} {"do":"back"} {"do":"wait"}. Max 4 actions. Click any user-requested visible page control when identifiable, including icon buttons, menus, tabs, links, toggles, and custom clickable elements. Prefer the exact visible label; use the numbered element index for DOM-listed targets. Use DOM labels and screenshot together when an image is supplied; otherwise use DOM/text only. Do not guess a target if uncertain. Never solve, click through, or bypass CAPTCHA, anti-bot, identity verification, MFA, passkey, or security challenges; stop and ask the user to complete them manually. A normal sign-in form by itself is not a security challenge. If the user explicitly requests a username to be entered, perform the fill action on the visible username field and report success only after the value is set. Never merely reply that you could fill it. Do not fill passwords unless explicitly supplied by the user; do not submit the form or bypass login. Type placeholders like {{SECRET1}} exactly as written, never guess credentials. Only send, buy, post or delete things if the goal clearly asks for it.';
  const parseJ = t => { try { t = String(t).replace(/```json|```/g, ""); const a = t.indexOf("{"), b = t.lastIndexOf("}"); return a >= 0 && b > a ? JSON.parse(t.slice(a, b + 1)) : null } catch (e) { return null } };
  function hideSecrets(text) {   // pull passwords out BEFORE the text goes to the AI; it only ever sees {{SECRETn}}
    const map = {}; let n = 0, out = text; const put = v => { const k = "{{SECRET" + (++n) + "}}"; map[k] = v.replace(/^["'“”]|["'“”]$/g, ""); return k };
    out = out.replace(/\b(give|put|type|enter|write|fill|set|insert)\s+("[^"]+"|\S+)\s+(?:in|into|as|for)\s+(?:the\s+)?(password|passcode|passwd|pass|pw)\b/ig, (m, v, x, f) => v + " " + put(x) + " in " + f);
    out = out.replace(/\b(password|passcode|passwd|pass|pw)\s*(?:is|:|=|-)?\s*("[^"]+"|'[^']+'|\S+)/ig, (m, k, v) => /^(?:and|then|in|on|to|for|click|press|next|field|box|\{\{.*)$/i.test(v) || /^[,;.]$/.test(v) ? m : k + " " + put(v));
    return { sent: out, map, shown: Object.values(map).reduce((a, v) => v ? a.split(v).join("•••••") : a, text) };
  }
  function pageChangedDuringReasoning(before, after) {
    try {
      const a = JSON.parse(before), b = JSON.parse(after);
      return a.url !== b.url || a.title !== b.title || a.text !== b.text || a.controls !== b.controls || a.count !== b.count;
    } catch (e) { return before !== after; }
  }

  async function clickAndVerify(fn, ...args) {
    const security = await run(P.securityState);
    if (security && security !== "OK") return "⛔ Click blocked: " + security + ". Complete the check manually in the visible browser.";
    const before = await run(P.state);
    const result = await run(fn, ...args);
    const raw = String(result || "");
    if (!raw.startsWith("ATTEMPTED:")) return raw === "NOTFOUND" || raw === "NOEL" ? "⚠ Click failed: target not found among visible controls in the live page. Try the exact button text or a more specific description." : "⚠ Click failed: " + (raw || "no result");
    const clickedAt = Date.now() + 350;
    await wait(1050);
    const after = await run(P.state);
    // Request a post-action frame too; state changes are the primary verification signal.
    const fresh = await latestFrame();
    const changed = !!before && !!after && before !== after;
    const label = raw.slice("ATTEMPTED:".length);
    if (changed) return "✓ Click at " + label + " — page-state change observed.";
    if (fresh && fresh.ts >= clickedAt) return "⚠ Click attempted at " + label + ", but the page did not visibly change; result unverified.";
    return "⚠ Click attempted at " + label + ", but no page-state change or fresh verification frame was available.";
  }

  async function agent(goal, map, act) {
    const out = [], hist = [], sub = x => String(x ?? "").replace(/\{\{SECRET\d+\}\}/g, k => map[k] ?? k); let bad = 0, n = 0;
    R.active = true; R.paused = false; R.stop = false;
    try {
      for (n = 1; n <= 14; n++) {
        while (R.paused && !R.stop) await wait(200);
        if (R.stop) { out.push("■ Stopped."); break }
        hud("Step " + n + ": looking at the page"); act.step("Looking at the page");
        const security = isOpen ? await run(P.securityState) : "OK";
        if (security && security !== "OK") { out.push("⛔ Stopped: " + security + ". Complete this check yourself in the visible browser, then give a new command."); break; }
        const stateBefore = isOpen ? await run(P.state) : "";
        const pg = isOpen ? await run(P.observe) : "(blank page, nothing open yet)";
        const textOnlyLocal = typeof window.curProv === 'function' && window.curProv() === 'local';
        const frame = isOpen && !textOnlyLocal ? await latestFrame() : null;
        if (isOpen && !frame && !textOnlyLocal) { out.push("⚠ I couldn't get a fresh screenshot from the visible browser. Frame capture state: " + perf.captureState + ". Visual analysis stopped instead of using an old frame."); break; }
        const userText = "GOAL: " + goal + "\nDONE SO FAR:\n" + (hist.slice(-8).join("\n") || "(nothing)") + "\nPAGE DOM/TEXT (accessible elements):\n" + String(pg).slice(0, 3200) + (textOnlyLocal ? "\nTEXT-ONLY LOCAL MODEL: use the accessible DOM/text only; no screenshot is available to the model. Do not guess icons or inaccessible controls." : "\nA fresh screenshot and the accessible DOM/text are available. Use both to identify the requested target.") + " Stop at security/authentication challenges.";
        const userContent = frame ? [{ type: "text", text: userText }, { type: "image_url", image_url: { url: frame.data } }] : userText;
        let rep; const aiStarted = Date.now();
        try { rep = await window.aiOnce([{ role: "system", content: SYS }, { role: "user", content: userContent }]); noteAnalysis(aiStarted, true); }
        catch (e) { noteAnalysis(aiStarted, false); out.push("⚠ AI analysis failed: " + e.message + ". Check the selected provider configuration and try again; Offline Brain mode does not use a model server."); break; }
        const j = parseJ(rep);
        if (!j) { if (++bad > 2) { out.push("⚠ The AI didn’t return usable steps. Try again with simpler wording."); break } hist.push("(invalid reply, retrying)"); continue }
        if (/captcha|robot check|verify you are human|anti.bot|security challenge|two.factor|verification code|passkey|identity verification/i.test(String(j.say || ""))) {
          out.push("⛔ Stopped because the visual analysis indicates a possible security/authentication challenge. Complete it manually in the visible browser."); break;
        }
        if (isOpen) {
          const securityNow = await run(P.securityState);
          if (securityNow && securityNow !== "OK") { out.push("⛔ Stopped: " + securityNow + ". Complete the check manually in the visible browser."); break; }
          const stateAfter = await run(P.state);
          if (pageChangedDuringReasoning(stateBefore, stateAfter)) {
            hist.push("discarded a stale AI response because the live page changed while it was being analyzed");
            continue;
          }
        }
        hud("Step " + n + ": " + (j.say || "working")); act.step(j.say || "Working");
        const acts = Array.isArray(j.actions) ? j.actions.slice(0, 4) : [];
        for (const a of acts) {
          while (R.paused && !R.stop) await wait(200); if (R.stop) break;
          const actionSecurity = isOpen ? await run(P.securityState) : "OK";
          if (actionSecurity && actionSecurity !== "OK") { hist.push("stopped at security control: " + actionSecurity); out.push("⛔ Stopped: " + actionSecurity + ". Complete it manually in the visible browser, then issue a new command."); R.stop = true; break; }
          if (a.do === "open" && /^https?:\/\//i.test(a.url || "")) { liveGo(a.url); await Promise.race([new Promise(r => loadRes = r), wait(12000)]); await wait(700); hist.push("opened " + a.url) }
          else if (a.do === "type") { const r = await run(P.fillIdx, a.i, sub(a.text)); hist.push(String(r).startsWith("OK") ? "typed into " + String(r).slice(3) + (/\{\{SECRET/.test(a.text || "") ? " (hidden)" : ": " + String(a.text).slice(0, 40)) : "FAILED to type into #" + a.i + " (not on page)"); await wait(400) }
          else if (a.do === "click") { const r = await clickAndVerify(P.clickIdx, a.i); hist.push(r); await wait(250) }
          else if (a.do === "enter") { await run(P.enter); hist.push("pressed Enter"); await wait(1500) }
          else if (a.do === "scroll") { await run(P.scroll, a.dir === "up" ? "up" : "down"); hist.push("scrolled " + (a.dir || "down")); await wait(500) }
          else if (a.do === "back") { B().nav("back"); hist.push("went back"); await wait(900) }
          else if (a.do === "wait") await wait(1500);
          await wait(R.delay / 2);
        }
        if (j.done || (!acts.length && !j.actions)) { out.push(j.say || "Done."); break }
        if (!acts.length) { if (++bad > 2) { out.push(j.say || "I’m not sure what to do next."); break } }
      }
      if (n > 14) out.push("I stopped after 14 steps. Tell me what to do next.");
    } finally { R.active = false; if (isOpen) hud(R.stop ? "Stopped" : "Done. Waiting for commands") }
    return out;
  }

  async function handle(text, act) {
    const t = text.trim();
    // while a run is going: pause / resume / stop, nothing else
    if (R.active) {
      const m = t.match(/^(pause|resume|continue|stop|cancel|abort)$/i);
      if (m) { const c = /^pause$/i.test(m[1]) ? "pause" : /^(resume|continue)$/i.test(m[1]) ? "resume" : "stop"; _ctl(c); return { reply: c === "stop" ? "Stopping…" : c === "pause" ? "⏸ Paused. Say **resume** to continue." : "▶ Resumed.", masked: text } }
      return parse(text) ? { reply: "A run is in progress. Say **pause** or **stop** first.", masked: text } : null;
    }
    let m;
    if ((m = t.match(/^speed\s+(slow|normal|fast)$/i))) { R.delay = { slow: 1800, normal: 700, fast: 150 }[m[1].toLowerCase()]; return { reply: "Speed: **" + m[1].toLowerCase() + "**", masked: text } }
    if ((m = t.match(/^(?:capture|live)\s+fps\s+(\d{1,2})$/i))) {
      const fps = Math.max(1, Math.min(15, parseInt(m[1], 10) || 1));
      try { B().setCaptureFps(fps); } catch (e) { return { reply: "Frame-rate control is unavailable in this build.", masked: text } }
      perf.limitFps = fps; renderTelemetry();
      return { reply: "Live capture limit set to **" + fps + " FPS** (hard cap 15; actual capture rate depends on rendering and device load).", masked: text };
    }
    if (/^(?:list\s+)?(?:saved\s+)?runs$/i.test(t)) { const n = Object.keys(RUNS()); return { reply: n.length ? "**Saved runs:** " + n.join(", ") + "\n\nRun one with `run NAME` (add `with PASSWORD` if it needs one)." : "No saved runs yet. Do something live, then say `save run NAME`.", masked: text } }
    if ((m = t.match(/^save\s+(?:this\s+)?run\s+(?:as\s+)?(.+)$/i)) && last.length) { const r = RUNS(), n = m[1].trim().toLowerCase();
      r[n] = last.map(s => s.t === "fill" && s.k === "password" ? { ...s, v: "{password}" } : s); localStorage.setItem("nano_runs", JSON.stringify(r));
      return { reply: "Saved run **" + n + "** (" + last.length + " steps). Passwords are never stored. Run it with `run " + n + (last.some(s => s.t === "fill" && s.k === "password") ? " with YOURPASSWORD" : "") + "`.", masked: text } }
    if ((m = t.match(/^(?:delete|remove)\s+run\s+(.+)$/i)) && RUNS()[m[1].trim().toLowerCase()]) { const r = RUNS(); delete r[m[1].trim().toLowerCase()]; localStorage.setItem("nano_runs", JSON.stringify(r)); return { reply: "Deleted run **" + m[1].trim() + "**.", masked: text } }
    let steps = null, pw = "";
    if ((m = t.match(/^run\s+(.+?)(?:\s+with\s+(.+))?$/i)) && RUNS()[m[1].trim().toLowerCase()]) {
      pw = (m[2] || "").trim(); const saved = RUNS()[m[1].trim().toLowerCase()];
      if (saved.some(s => s.v === "{password}") && !pw) return { reply: "This run needs your password. Say `run " + m[1].trim() + " with YOURPASSWORD`.", masked: text };
      steps = saved.map(s => s.v === "{password}" ? { ...s, v: pw } : s);
    } else steps = parse(text);
    if (!steps) {   // not a fixed command: let the AI agent do it (only when live is open or you said "go live ...")
      const gl = t.match(/^(?:go|start|begin)\s+live(?:\s*(?:stream|view))?\b[\s,]*(?:and|then)?\s*(.*)$/i);
      if (!gl && !isOpen) return null;
      if (!B()) return { reply: "Live stream isn’t available in this build.", masked: text };
      if (!window.aiOnce) return null;
      const hs = hideSecrets(gl ? gl[1] : t); if (gl) liveGo("https://bot.nebulanetwork.club/")
      const out = await agent(hs.sent, hs.map, act);
      return { reply: out.join("\n\n"), masked: hideSecrets(t).shown };
    }
    if (!B()) return { reply: "Live stream isn’t available in this build.", masked: text };
    const need = steps.some(s => !["open", "close", "golive"].includes(s.t));
    if (need && !isOpen && !steps.some(s => s.t === "open" || s.t === "golive" || s.t === "desktop")) return null;   // no live page: treat as normal chat
    const out = await exec(steps, act);
    const keep = steps.filter(s => !["close", "read", "golive"].includes(s.t)); if (keep.length) last = keep;
    let mt = t; for (const s of steps) if (s.t === "fill" && s.k === "password" && s.v) mt = mt.split(s.v).join("•••••");
    if (pw) mt = mt.split(pw).join("•••••");
    return { reply: out.join("\n\n"), masked: mt };
  }
  if (typeof window !== "undefined") window.setInterval(renderTelemetry, 1000);
  return { handle, _done, _loaded, _ctl, _closed, _nativePaused, _frameReceived, _nativeTelemetry, _desktopChanged };
})();
