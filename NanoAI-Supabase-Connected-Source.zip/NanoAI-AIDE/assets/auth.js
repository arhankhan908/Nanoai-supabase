(() => {
const C = window.NANO, API = C.BACKEND_URL.startsWith("http") ? C.BACKEND_URL.replace(/\/$/, "") : "", TV = "2026-10";
const LOCAL = !/^https?:\/\//.test(C.SUPABASE_URL || "") || /PASTE/.test(C.SUPABASE_ANON_KEY || "");   // no Supabase set up: accounts live on this device
const J = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } }, W = (k, v) => localStorage.setItem(k, JSON.stringify(v));
const uid = () => crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random().toString(16).slice(2);
function localSB() {
  const hash = async s => { try { const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("") } catch { let h = 5381; for (const c of s) h = (h * 33 ^ c.charCodeAt(0)) >>> 0; return "x" + h } };
  const cur = () => J("nano_users", {})[J("nano_session", "")] || null, pub = u => u && { id: u.id, email: u.email, user_metadata: u.meta }, cbs = [];
  const emit = ev => { const u = cur(); cbs.forEach(f => f(ev, u ? { user: pub(u) } : null)) };
  const seed = async () => { const us = J("nano_users", {}); for (const a of C.ACCOUNTS || []) { const k = a.email.toLowerCase(); if (us[k]) continue;
    const salt = uid(); us[k] = { id: uid(), email: k, salt, hash: await hash(salt + a.password), meta: { age_ok: true, accepted_at: new Date().toISOString(), terms_version: TV } } } W("nano_users", us) };
  return { auth: {
    onAuthStateChange(f) { cbs.push(f); seed().then(() => emit("INITIAL_SESSION")); return { data: { subscription: {} } } },
    async getSession() { const u = cur(); return { data: { session: u ? { access_token: "local", user: pub(u) } : null } } },
    async getUser() { return { data: { user: pub(cur()) } } },
    async signUp({ email, password, options }) { const us = J("nano_users", {}), k = email.toLowerCase();
      if (us[k]) return { error: { message: "An account with this email already exists. Log in instead." } };
      const salt = uid(); us[k] = { id: uid(), email: k, salt, hash: await hash(salt + password), meta: options?.data || {} };
      W("nano_users", us); W("nano_session", k); emit("SIGNED_IN"); return { error: null } },
    async signInWithPassword({ email, password }) { const u = J("nano_users", {})[email.toLowerCase()];
      if (!u || u.hash !== await hash(u.salt + password)) return { error: { message: "Invalid login credentials" } };
      W("nano_session", u.email); emit("SIGNED_IN"); return { error: null } },
    async signOut() { localStorage.removeItem("nano_session"); emit("SIGNED_OUT"); return {} },
    async updateUser({ password, data }) { const us = J("nano_users", {}), u = us[J("nano_session", "")]; if (!u) return { error: { message: "Not logged in." } };
      if (password) { u.salt = uid(); u.hash = await hash(u.salt + password) } if (data) u.meta = { ...u.meta, ...data }; W("nano_users", us); return { error: null } },
    async resetPasswordForEmail() { return { error: { message: "Email reset isn’t available for on-device accounts. Create a new account instead." } } },
    async signInWithOAuth() {} } } }
const sb = LOCAL ? localSB() : supabase.createClient(C.SUPABASE_URL, C.SUPABASE_ANON_KEY), $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"]/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]));
const ORIGIN = location.protocol.startsWith("http") ? location.origin : API;   // app/WebView (file://) has no usable origin
let user = null, prof = null, mode = "login";
const token = async () => (await sb.auth.getSession()).data.session?.access_token || "";
const api = async (p, b) => fetch(API + p, { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + await token() }, body: JSON.stringify(b) });
const say = (m, ok) => { $("amsg").textContent = m; $("amsg").style.color = ok ? "#2EA66A" : "#E5484D" };
const age = d => { const b = new Date(d), n = new Date(); let a = n.getFullYear() - b.getFullYear(); if (n < new Date(n.getFullYear(), b.getMonth(), b.getDate())) a--; return a };

function noAccount(em) {
  const m = $("acct"); m.classList.remove("off");
  m.innerHTML = `<div class="box pop"><div class="ico">?</div><h2>Account not found</h2><p class="fine">There’s no Nano Ai account for <b>${esc(em)}</b>.<br>Want to create one instead?</p>
   <button class="btn pri" id="nc">Create account</button><button class="btn" id="nx">Cancel</button></div>`;
  $("nc").onclick = () => { m.classList.add("off"); setMode("signup"); $("em").value = em; $("pw").value = ""; $("pw").focus() };
  $("nx").onclick = () => { m.classList.add("off"); $("pw").value = ""; say("") } }
function setMode(m) { mode = m; $("su").hidden = m === "login"; $("em").hidden = $("pw").hidden = m === "gate"; $("goog").hidden = m === "gate" || LOCAL;
  $("atitle").textContent = { login: "Log in", signup: "Create account", gate: "Confirm to continue" }[m]; $("ago").textContent = { login: "Log in", signup: "Create account", gate: "Confirm" }[m];
  $("tSwap").textContent = m === "login" ? "Create account" : "Log in"; $("links").hidden = m === "gate"; say("") }

const Cloud = LOCAL ? {
  key: () => "nano_chats_" + user.id,
  async pull() { S = { active: null, chats: J(this.key(), []) }; if (!S.chats.length) newChat(); else { S.active = S.chats[0].id; draw() } },
  async push(c) { if (!user || !c) return; const d = J(this.key(), []).filter(x => x.id !== c.id); d.unshift({ id: c.id, title: c.title, pinned: !!c.pinned, msgs: c.msgs.map(m => ({ ...m, imgs: undefined })) }); try { W(this.key(), d) } catch {} },
  async del(id) { W(this.key(), J(this.key(), []).filter(x => x.id !== id)) },
  async wipe() { localStorage.removeItem(this.key()) },
  async saveKey(provider, payload) { const all=J("nano_local_vault_"+user.id,{}); all[provider]=payload; W("nano_local_vault_"+user.id,all); return { localOnly:true }; },
  async loadKey(provider) { return { payload:(J("nano_local_vault_"+user.id,{})||{})[provider]||null }; },
  async removeKey(provider) { const all=J("nano_local_vault_"+user.id,{}); delete all[provider]; W("nano_local_vault_"+user.id,all); return {}; }
} : {
  async pull() { const { data } = await sb.from("chats").select("*").order("updated_at", { ascending: false });
    S = { active: null, chats: (data || []).map(r => ({ id: r.id, title: r.title, msgs: r.msgs || [], pinned: r.pinned })) };
    if (!S.chats.length) newChat(); else { S.active = S.chats[0].id; draw() } },
  async push(c) { if (!user || !c) return; await sb.from("chats").upsert({ id: c.id, user_id: user.id, title: c.title, msgs: c.msgs.map(m => ({ ...m, imgs: undefined })), pinned: !!c.pinned, updated_at: new Date().toISOString() }) },
  async del(id) { await sb.from("chats").delete().eq("id", id) },
  async wipe() { await sb.from("chats").delete().eq("user_id", user.id) },
  async saveKey(provider, payload) { return await sb.from("api_key_vault").upsert({ user_id:user.id, provider, payload, updated_at:new Date().toISOString() }, { onConflict:"user_id,provider" }); },
  async loadKey(provider) { const { data, error } = await sb.from("api_key_vault").select("payload").eq("user_id",user.id).eq("provider",provider).maybeSingle(); return { payload:data?.payload||null, error }; },
  async removeKey(provider) { return await sb.from("api_key_vault").delete().eq("user_id",user.id).eq("provider",provider); }
};
async function usage() {
  if (LOCAL) { $("usage").textContent = "Saved on this device"; return }
  const { data } = await sb.from("profiles").select("*").eq("id", user.id).single(); prof = data; if (!data) return;
  const used = data.used_on === new Date().toISOString().slice(0, 10) ? data.used : 0;
  $("usage").innerHTML = data.is_admin ? "Unlimited (admin)" : `<div class="bar"><i style="width:${Math.min(100, used / data.daily_limit * 100)}%"></i></div>${used.toLocaleString()} / ${data.daily_limit.toLocaleString()} tokens today`;
}
async function enter() { user = (await sb.auth.getUser()).data.user; $("auth").classList.add("off"); await Cloud.pull(); await usage() }

$("ago").onclick = async () => {
  const em = $("em").value.trim(), pw = $("pw").value;
  if (mode !== "gate" && !/^\S+@\S+\.\S+$/.test(em)) return say("Enter a valid email address.");
  if (mode === "login") { if (!pw) return say("Enter your password.");
    const btn = $("ago"); btn.disabled = true; const { error } = await sb.auth.signInWithPassword({ email: em, password: pw }); btn.disabled = false;
    if (!error) return;
    if (/invalid login/i.test(error.message)) {   // wrong password OR no such account: ask the server which
      const r = LOCAL ? { exists: !!J("nano_users", {})[em.toLowerCase()] } : await fetch(API + "/api/account", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "exists", email: em }) }).then(x => x.json()).catch(() => ({}));
      if (r.exists === false) return noAccount(em);
      return say("Incorrect password. Try again, or use Forgot password.") }
    return say(error.message) }
  if (!$("dob").value || age($("dob").value) < 18 || !$("c18").checked) {
    if (mode === "gate") { await api("/api/account", { action: "delete" }); await sb.auth.signOut() }   // under 18: remove the account
    return say("You must be 18 or older to use Nano Ai. No account was created.") }
  if (!$("cT").checked) return say("Please accept the Terms, Privacy Policy and Acceptable Use rules.");
  const data = { age_ok: true, accepted_at: new Date().toISOString(), terms_version: TV };
  if (mode === "gate") { const { error } = await sb.auth.updateUser({ data }); if (error) return say(error.message); return enter() }
  if (pw.length < 8) return say("Password needs 8 or more characters.");
  const { error } = await sb.auth.signUp({ email: em, password: pw, options: { data, emailRedirectTo: ORIGIN } });
  if (error) return say(error.message); if (LOCAL) return; setMode("login"); say("Check your email to verify your account, then log in.", 1);
};
$("tSwap").onclick = e => { e.preventDefault(); setMode(mode === "login" ? "signup" : "login") };
$("tReset").onclick = async e => { e.preventDefault(); const em = $("em").value.trim(); if (!em) return say("Type your email first.");
  const { error } = await sb.auth.resetPasswordForEmail(em, { redirectTo: ORIGIN }); say(error ? error.message : "Reset link sent. Check your email.", !error) };
$("goog").onclick = () => sb.auth.signInWithOAuth({ provider: "google", options: { redirectTo: ORIGIN } });

sb.auth.onAuthStateChange((ev, s) => {
  if (ev === "PASSWORD_RECOVERY") setTimeout(() => { const p = prompt("New password (8+ characters)"); if (p && p.length >= 8) sb.auth.updateUser({ password: p }).then(() => alert("Password changed.")) }, 0);
  user = s?.user || null;
  if (!user) { localStorage.removeItem("nano_store"); prof = null; setMode("login"); $("auth").classList.remove("off"); return }
  if (!user.user_metadata?.age_ok) { setMode("gate"); $("auth").classList.remove("off"); return }
  setTimeout(enter, 0);
});

// ---- account / settings / admin ----
$("acctBtn").onclick = async () => {
  await usage(); const m = $("acct"); m.classList.remove("off");
  m.innerHTML = `<div class="box"><h2>Account</h2><p class="fine">${esc(user.email)}</p>
   <input id="np" type="password" placeholder="New password (8+ characters)"><button class="btn" id="cp">Change password</button>
   ${LOCAL ? `<select id="pv">${Object.entries(PROV).map(([k, v]) => `<option value="${k}"${k === curProv() ? " selected" : ""}>${v.name}</option>`).join("")}</select><input id="gk" type="password" placeholder="${PROV[curProv()].ph}" value="${esc(localStorage.getItem("nano_" + curProv()) || "")}"><button class="btn" id="sk">Save AI key</button>` : ""}<button class="btn" id="del">Delete my account</button><button class="btn" id="lo">Log out</button>
   <div id="adm"></div><p id="am2" class="fine"></p><button class="btn pri" id="cl">Close</button></div>`;
  $("cl").onclick = () => m.classList.add("off");
  $("cp").onclick = async () => { const v = $("np").value; if (v.length < 8) return $("am2").textContent = "8+ characters please."; const { error } = await sb.auth.updateUser({ password: v }); $("am2").textContent = error ? error.message : "Password changed." };
  if (LOCAL) { $("pv").onchange = () => { const p = $("pv").value; $("gk").value = localStorage.getItem("nano_" + p) || ""; $("gk").placeholder = PROV[p].ph };
    $("sk").onclick = () => { const p = $("pv").value, v = $("gk").value.trim(); v ? localStorage.setItem("nano_" + p, v) : localStorage.removeItem("nano_" + p); localStorage.setItem("nano_prov", p);
      $("am2").textContent = v ? (n => n + " " + PROV[p].name + " key" + (n > 1 ? "s" : "") + " saved. Nano Ai now uses " + PROV[p].name + (n > 1 ? " and rotates between the keys." : "."))(v.split(/[\s,]+/).filter(Boolean).length) : PROV[p].name + " key removed."; window.keyBadge?.(); } }
  $("del").onclick = async () => {
    if (LOCAL) { if (prompt('Type DELETE to permanently delete your account and all chats') !== "DELETE") return; const us = J("nano_users", {}); delete us[user.email.toLowerCase()]; W("nano_users", us); localStorage.removeItem("nano_chats_" + user.id); await sb.auth.signOut(); return location.reload() } if (prompt('Type DELETE to permanently delete your account and all chats') !== "DELETE") return;
    const r = await api("/api/account", { action: "delete" }); if (r.ok) { await sb.auth.signOut(); location.reload() } else $("am2").textContent = "Couldn’t delete. Try again." };
  $("lo").onclick = async () => { await sb.auth.signOut(); location.reload() };
  if (!LOCAL && prof?.is_admin) admin($("adm"));
};
async function admin(box) {
  const us = await (await api("/api/admin", { action: "list" })).json(); if (!Array.isArray(us)) return;
  box.innerHTML = "<b>Admin</b>" + us.map(u => `<div class="ur"><span>${esc(u.email)}${u.banned ? " 🚫" : ""}</span><small>${u.used_on === new Date().toISOString().slice(0, 10) ? u.used : 0} used</small><input type="number" class="lim" data-id="${u.id}" value="${u.daily_limit}"><button class="btn" data-b="${u.id}" data-v="${!u.banned}">${u.banned ? "Unban" : "Ban"}</button></div>`).join("");
  box.querySelectorAll(".lim").forEach(i => i.onchange = () => api("/api/admin", { action: "update", id: i.dataset.id, daily_limit: +i.value }));
  box.querySelectorAll("[data-b]").forEach(b => b.onclick = async () => { await api("/api/admin", { action: "update", id: b.dataset.b, banned: b.dataset.v === "true" }); admin(box) });
}
window.Auth = { token, usage, local: LOCAL }; window.Cloud = Cloud;
// Sync custom examples independently from Nano's optional email/account backend.
// If cloud settings are absent or network/auth fails, Nano keeps using local examples.
if (window.NanoCloudSync && window.NanoOffline) {
  window.NanoCloudSync.syncLessons(window.NanoOffline.lessons()).catch(function () {});
}
})();
