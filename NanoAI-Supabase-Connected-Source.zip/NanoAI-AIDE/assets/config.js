// ===== EDIT ME =====
window.NANO = {
  BACKEND_URL: "https://storied-marshmallow-318421.netlify.app",
  SUPABASE_URL: "PASTE_SUPABASE_PROJECT_URL",      // Supabase > Project Settings > API
  SUPABASE_ANON_KEY: "PASTE_SUPABASE_ANON_KEY",    // optional account/chat backend (public anon key)
  // Optional: private per-install cloud backup for Nano teaching examples. Enable Supabase Anonymous Sign-ins.
  CLOUD_SYNC_URL: "https://slxwpurkwnnlrjqneyrm.supabase.co",
  CLOUD_SYNC_ANON_KEY: "sb_publishable_PEAJETPQlwxKy8cxuV2cEw_oIc6SROL",
  ACCOUNTS: [],   // Never ship real account credentials in source code
  LOCAL_AI_URL: "offline://", // built-in no-server offline brain
  // For a PRIVATE local build only: add rotated Groq key(s), comma-separated.
  // Never commit/share this file or distribute an APK containing these keys.
  GROQ_API_KEY: "",
  MISTRAL_API_KEY: "",   // optional; or paste it in the app: Account > AI key
    // optional: your Groq key for local mode (or paste it in the app: Account > AI key)
  NAME: "Nano Ai", MODEL_LABEL: "Nano Offline Brain"
};
