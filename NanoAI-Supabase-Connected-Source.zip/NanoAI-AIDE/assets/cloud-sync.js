/* Supabase backup for Nano's user-taught examples.
   Uses a per-install anonymous Auth session and the nano_ai_lessons table.
   Public/publishable key only; row ownership is enforced by Supabase RLS. */
(function () {
  "use strict";
  var LESSON_KEY = "nano_offline_lessons_v1";
  var TABLE = "nano_ai_lessons";
  var c = window.NANO || {};
  var url = String(c.CLOUD_SYNC_URL || "").trim().replace(/\/$/, "");
  var anonKey = String(c.CLOUD_SYNC_ANON_KEY || "").trim();
  var configured = /^https:\/\//i.test(url) && !!anonKey && !/PASTE/i.test(url + " " + anonKey);
  var client = null, bootPromise = null, saveTimer = null, lastError = "";

  function localLessons() {
    try {
      var data = JSON.parse(localStorage.getItem(LESSON_KEY) || "[]");
      return Array.isArray(data) ? data.filter(validPair).slice(-500) : [];
    } catch (_) { return []; }
  }
  function validPair(p) {
    return Array.isArray(p) && p.length === 2 && typeof p[0] === "string" && typeof p[1] === "string" && p[0].trim().length > 0 && p[0].trim().length <= 500 && p[1].trim().length > 0 && p[1].trim().length <= 2000;
  }
  function normalized(v) { return String(v || "").trim().toLocaleLowerCase(); }
  function merge(a, b) {
    var map = new Map();
    (Array.isArray(a) ? a : []).concat(Array.isArray(b) ? b : []).forEach(function (p) {
      if (!validPair(p)) return;
      map.set(normalized(p[0]), [p[0].trim(), p[1].trim()]);
    });
    return Array.from(map.values()).slice(-500);
  }
  function keyFor(prompt) { return normalized(prompt); }
  async function ready() {
    if (!configured) return null;
    if (client) return client;
    if (bootPromise) return bootPromise;
    bootPromise = (async function () {
      if (!window.supabase || typeof window.supabase.createClient !== "function") throw new Error("Supabase SDK did not load. Check internet access.");
      client = window.supabase.createClient(url, anonKey, {
        auth: { storageKey: "nano_cloud_sync_auth_v1", persistSession: true, autoRefreshToken: true, detectSessionInUrl: false }
      });
      var sessionResult = await client.auth.getSession();
      if (sessionResult.error) throw sessionResult.error;
      if (!sessionResult.data.session) {
        var signIn = await client.auth.signInAnonymously();
        if (signIn.error) throw new Error("Enable Anonymous Sign-ins in Supabase Authentication settings: " + signIn.error.message);
      }
      return client;
    })().catch(function (e) { bootPromise = null; client = null; lastError = String(e && e.message || e); throw e; });
    return bootPromise;
  }
  async function userId(sb) {
    var result = await sb.auth.getUser();
    if (result.error) throw result.error;
    if (!result.data.user) throw new Error("Cloud backup has no authenticated session.");
    return result.data.user.id;
  }
  async function readCloud(sb, uid) {
    var result = await sb.from(TABLE).select("lesson_key,trigger_text,response_text").eq("user_id", uid).limit(500);
    if (result.error) throw result.error;
    return (result.data || []).map(function (r) { return [r.trigger_text, r.response_text]; }).filter(validPair);
  }
  async function writeLessons(sb, uid, lessons) {
    var rows = merge([], lessons).map(function (p) {
      return { user_id: uid, lesson_key: keyFor(p[0]), trigger_text: p[0], response_text: p[1], updated_at: new Date().toISOString() };
    });
    var existingResult = await sb.from(TABLE).select("lesson_key").eq("user_id", uid).limit(1000);
    if (existingResult.error) throw existingResult.error;
    var keep = new Set(rows.map(function (r) { return r.lesson_key; }));
    for (var i = 0; i < (existingResult.data || []).length; i++) {
      var oldKey = existingResult.data[i].lesson_key;
      if (!keep.has(oldKey)) {
        var del = await sb.from(TABLE).delete().eq("user_id", uid).eq("lesson_key", oldKey);
        if (del.error) throw del.error;
      }
    }
    if (rows.length) {
      var saved = await sb.from(TABLE).upsert(rows, { onConflict: "user_id,lesson_key" });
      if (saved.error) throw saved.error;
    }
  }
  async function syncLessons() {
    var local = localLessons();
    if (!configured) return local;
    try {
      var sb = await ready();
      var uid = await userId(sb);
      var cloud = await readCloud(sb, uid);
      var combined = merge(cloud, local); // local edits win on matching prompts
      localStorage.setItem(LESSON_KEY, JSON.stringify(combined));
      await writeLessons(sb, uid, combined);
      lastError = "";
      return combined;
    } catch (e) {
      lastError = String(e && e.message || e);
      console.warn("Nano cloud sync failed; local lessons remain available.", lastError);
      return local;
    }
  }
  async function saveNow(lessons) {
    if (!configured) return false;
    try {
      var sb = await ready();
      var uid = await userId(sb);
      await writeLessons(sb, uid, lessons);
      lastError = "";
      return true;
    } catch (e) {
      lastError = String(e && e.message || e);
      console.warn("Nano cloud lesson backup failed; local lessons remain saved.", lastError);
      return false;
    }
  }
  function saveLessons(lessons) {
    if (!configured) return false;
    clearTimeout(saveTimer);
    var snapshot = merge([], lessons);
    saveTimer = setTimeout(function () { saveNow(snapshot); }, 350);
    return true;
  }
  window.NanoCloudSync = {
    enabled: function () { return configured; },
    syncLessons: syncLessons,
    saveLessons: saveLessons,
    status: function () { return { enabled: configured, ready: !!client, error: lastError }; }
  };
  // Pull cloud lessons once after page scripts load; offline use is unaffected on failure.
  if (configured) setTimeout(function () { syncLessons(); }, 0);
})();
