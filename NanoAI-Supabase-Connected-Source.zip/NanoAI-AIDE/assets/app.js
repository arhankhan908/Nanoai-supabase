const C = window.NANO, $ = id => document.getElementById(id);
const BASE = C.BACKEND_URL.startsWith("http") ? C.BACKEND_URL.replace(/\/$/, "") : "";
const ENDPOINT = BASE + "/api/chat";
const ld = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } };
const sv = () => { try { localStorage.setItem("nano_store", JSON.stringify(S)) } catch {} window.Cloud?.push(cur()) };
let queue = [], S = ld("nano_store", { active: null, chats: [] }), pending = [], deep = false, ctrl = null, busy = false;
const cur = () => S.chats.find(c => c.id === S.active);
function newChat() { const c = { id: crypto.randomUUID(), title: "New chat", msgs: [] }; S.chats.unshift(c); S.active = c.id; sv(); draw(); }

const esc = s => s.replace(/[&<>]/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[m]));
function md(t) {
  let s = esc(t);
  s = s.replace(/```\w*\n?([\s\S]*?)```/g, (_, c) => `<pre><code>${c.trim()}</code></pre>`);
  s = s.replace(/`([^`\n]+)`/g, "<code>$1</code>").replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>");
  s = s.replace(/^#{1,3} (.+)$/gm, "<h3>$1</h3>").replace(/^[-*] (.+)$/gm, "<ul><li>$1</li></ul>").replace(/<\/ul>\n<ul>/g, "");
  return s.replace(/\n(?!<)/g, "<br>");
}
function bubble(role, m) {
  const d = document.createElement("div"); d.className = "msg " + role;
  const imgs = (m.imgs || []).map(u => `<img src="${u}" alt="">`).join("");
  d.innerHTML = imgs + (role === "user" ? esc(m.show ?? m.text) : md(m.text)); $("feed").appendChild(d);
  $("feed").scrollTop = 1e9; return d;
}
function draw() {
  const c = cur(); $("title").textContent = c.title; $("list").innerHTML = "";
  S.chats.forEach(x => { const e = document.createElement("div"); e.className = "it" + (x.id === S.active ? " on" : "");
    e.innerHTML = `<span>${esc(x.title)}</span><b>✕</b>`;
    e.onclick = ev => { if (ev.target.tagName === "B") { S.chats = S.chats.filter(y => y !== x); window.Cloud?.del(x.id); if (!S.chats.length) return newChat(); S.active = S.chats[0].id } else S.active = x.id; sv(); draw(); $("side").classList.remove("open") };
    $("list").appendChild(e) });
  $("feed").innerHTML = c.msgs.length ? "" : `<div class="empty"><div class="orb"></div><h2>What can ${C.NAME} do for you?</h2><p>Pick a starting point or just type.</p>
   <div class="tiles"><button class="tile" data-p="Explain something complex in simple terms. Ask me what topic."><b>✦</b>Explain anything<small>Simple, clear answers</small></button>
   <button class="tile" data-p="Help me write code. Ask me what I’m building."><b>⌘</b>Code with me<small>Write, fix, explain</small></button>
   <button class="tile" data-p="Help me write something. Ask me what it’s for."><b>✎</b>Write it for me<small>Posts, emails, essays</small></button>
   <button class="tile" data-p="photo"><b>▣</b>Analyze a photo<small>Upload and ask</small></button></div></div>`;
  $("feed").querySelectorAll(".tile").forEach(t => t.onclick = () => { if (t.dataset.p === "photo") return $("photo").click(); $("in").value = t.dataset.p; send() });
  c.msgs.forEach(m => bubble(m.role === "assistant" ? "bot" : m.role === "system" ? "sys" : "user", m));
  const lm = c.msgs[c.msgs.length - 1];
  if (lm?.chips) { const w = document.createElement("div"); w.className = "qchips";
    w.innerHTML = lm.chips.map(x => `<button class="qc">${esc(x)}</button>`).join("") + `<button class="qc alt">Something else…</button>`;
    w.querySelectorAll(".qc").forEach(b => b.onclick = () => { if (b.classList.contains("alt")) return $("in").focus(); $("in").value = b.textContent; send() }); $("feed").appendChild(w); $("feed").scrollTop = 1e9 }
  $("chips").innerHTML = pending.map((p, i) => `<span class="chip" data-i="${i}">${esc(p.name)} ✕</span>`).join("");
  $("chips").querySelectorAll(".chip").forEach(e => e.onclick = () => { pending.splice(+e.dataset.i, 1); draw() });
  $("deep").classList.toggle("on", deep); $("send").textContent = busy ? "Stop" : "Send";
}

// ---- attachments ----
function shrink(file) { return new Promise(res => { const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => {
  const k = Math.min(1, 1024 / Math.max(im.width, im.height)), cv = document.createElement("canvas");
  cv.width = im.width * k; cv.height = im.height * k; cv.getContext("2d").drawImage(im, 0, 0, cv.width, cv.height); res(cv.toDataURL("image/jpeg", .8)) }; im.src = r.result }; r.readAsDataURL(file) }) }
const addFiles = async e => {
  for (const f of e.target.files) {
    if (f.size > 8e6) { cur().msgs.push({ role: "system", text: `⚠ ${f.name} is over 8 MB.` }); continue }
    if (f.type.startsWith("image/")) pending.push({ name: f.name, img: await shrink(f) });
    else pending.push({ name: f.name, txt: (await f.text()).slice(0, 30000) });
  } e.target.value = ""; draw();
};
$("file").onchange = $("photo").onchange = addFiles;
$("plus").onclick = e => { e.stopPropagation(); $("am").hidden = !$("am").hidden };
$("mPhoto").onclick = () => { $("am").hidden = true; $("photo").click() };
$("mFile").onclick = () => { $("am").hidden = true; $("file").click() };
document.addEventListener("click", () => { $("am").hidden = true });

// ---- AI providers (all OpenAI-style APIs): your own key, stored only on this device ----
// First-run migration: make Local AI the default without deleting any existing provider keys.
if (!localStorage.getItem("nano_provider_default_migrated")) { localStorage.setItem("nano_prov", "local"); localStorage.setItem("nano_provider_default_migrated", "1"); }
const PROV = { local: { name: "Offline Brain", url: "offline://", ph: "No API key required", budget: 8000 }, groq: { name: "Groq", url: "https://api.groq.com/openai/v1", ph: "Groq key(s) gsk_… (separate several with commas)", budget: 11000 }, mistral: { name: "Mistral", url: "https://api.mistral.ai/v1", ph: "Mistral key(s) (separate several with commas)", budget: 40000 } };
const provKey = p => p === "local" ? "" : (localStorage.getItem("nano_" + p) || (p === "groq" ? C.GROQ_API_KEY : C.MISTRAL_API_KEY) || "");
const curProv = () => { const p = localStorage.getItem("nano_prov"); return PROV[p] ? p : "local"; };
const keysOf = p => provKey(p).split(/[\s,]+/).filter(Boolean), KI = {}, COOL = {};
function keyBadge() {   // header: which key is in use and how many you gave
  const el = $("keyb"); if (!el) return;
  const P = curProv(); if (P === "local") { el.textContent = "Offline Brain · no network"; el.style.color = "#55d6a3"; return }
  if (!window.Auth?.local && !keysOf(P).length) { el.textContent = ""; return }
  const ks = keysOf(P), now = Date.now(), lim = ks.filter(k => COOL[k] > now).length;
  if (!ks.length) { el.textContent = PROV[P].name + " · no key"; el.style.color = "#E5484D"; return }
  const i = (KI[P] || 0) % ks.length;
  el.textContent = PROV[P].name + " · key " + (i + 1) + "/" + ks.length + " (…" + ks[i].slice(-4) + ")" + (lim ? " · " + lim + " limited" : "");
  el.style.color = lim === ks.length ? "#E5484D" : lim ? "#FFB400" : "";
}
window.keyBadge = keyBadge; setInterval(keyBadge, 1500); setTimeout(keyBadge, 300);
window.PROV = PROV; window.provKey = provKey; window.curProv = curProv;

// Key entry is opened as a floating panel; the secret never becomes a chat message.
const keyPrompt = t => /\b(?:i\s+want\s+to\s+(?:give|add|set)|give|add|set|save|enter|update|change)\s+(?:(?:my|a|an|new)\s+)*(?:(?:groq|mistral)\s+)?(?:api\s+)?keys?\b/i.test(t) || /\b(?:give|add|paste|save|set)\s+(?:me\s+)?(?:the\s+)?(?:groq|mistral|api)\s+key\b/i.test(t);
const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes)));
const un64 = str => Uint8Array.from(atob(str), c => c.charCodeAt(0));
async function vaultEncrypt(value, pass) {
  if (!crypto.subtle) throw new Error('Secure encryption is unavailable in this WebView.');
  const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveKey']);
  const key = await crypto.subtle.deriveKey({ name:'PBKDF2', salt, iterations:310000, hash:'SHA-256' }, material, { name:'AES-GCM', length:256 }, false, ['encrypt']);
  const encrypted = await crypto.subtle.encrypt({ name:'AES-GCM', iv }, key, new TextEncoder().encode(value));
  return { version:1, salt:b64(salt), iv:b64(iv), data:b64(encrypted) };
}
async function vaultDecrypt(payload, pass) {
  if (!crypto.subtle || !payload || payload.version !== 1) throw new Error('No compatible encrypted cloud key was found.');
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveKey']);
  const key = await crypto.subtle.deriveKey({ name:'PBKDF2', salt:un64(payload.salt), iterations:310000, hash:'SHA-256' }, material, { name:'AES-GCM', length:256 }, false, ['decrypt']);
  const clear = await crypto.subtle.decrypt({ name:'AES-GCM', iv:un64(payload.iv) }, key, un64(payload.data));
  return new TextDecoder().decode(clear);
}
function openKeyModal(provider, preset) {
  let modal = $('keyvault');
  if (!modal) {
    modal = document.createElement('div'); modal.id = 'keyvault'; modal.className = 'keyvault-overlay';
    modal.innerHTML = `<section class="keyvault-card" role="dialog" aria-modal="true" aria-labelledby="kvtitle"><div class="keyvault-head"><div><h2 id="kvtitle">Add an AI key</h2><p>Paste your key here. It will not be sent as a chat message.</p></div><button class="kv-close" id="kvclose" aria-label="Close">✕</button></div><label for="kvprovider">Provider</label><select id="kvprovider"><option value="local">Offline Brain (no server)</option><option value="groq">Groq</option><option value="mistral">Mistral</option></select><div id="localfields" hidden><p class="kv-note">On-device Offline Brain. No API key, localhost server, Wi-Fi endpoint, or AI network request is used. It uses built-in browser-command rules and local examples you teach it. This starter is not a full generative model.</p></div><div id="keyfields"><label for="kvkeys">API key(s)</label><textarea id="kvkeys" rows="3" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Paste one key, or several separated by commas"></textarea></div><label for="kvpass">Cloud vault passphrase <small>(needed for encrypted cloud sync)</small></label><input id="kvpass" type="password" autocomplete="new-password" placeholder="Choose/enter vault passphrase (8+ characters)"><p class="kv-note" id="kvnote"></p><div class="kv-actions"><button class="btn" id="kvrestore">Restore from cloud</button><button class="btn pri" id="kvsave">Save key</button></div><button class="btn kv-remove" id="kvremove">Remove saved key</button></section>`;
    document.body.appendChild(modal);
    $('kvclose').onclick = () => { modal.classList.remove('show'); $('kvkeys').value=''; $('kvpass').value=''; };
    modal.addEventListener('click', e => { if (e.target === modal) $('kvclose').click(); });
    $('kvprovider').onchange = () => { const q=$('kvprovider').value; $('kvkeys').value=''; $('kvkeys').placeholder=PROV[q].ph; localStorage.setItem('nano_prov',q); const local=q==='local'; $('localfields').hidden=!local; $('keyfields').hidden=local; $('kvpass').hidden=local; modal.querySelector('label[for=kvpass]').hidden=local; $('kvrestore').hidden=local; $('kvremove').hidden=local; $('kvsave').textContent=local?'Enable offline mode':'Save key'; if(local){localStorage.setItem('nano_offline_enabled','1');} }; 
    $('kvsave').onclick = async () => {
      const q=$('kvprovider').value, v=$('kvkeys').value.trim(), pass=$('kvpass').value, note=$('kvnote');
      if(q==='local'){ localStorage.setItem('nano_prov','local'); localStorage.setItem('nano_offline_enabled','1'); window.keyBadge?.(); note.textContent='Offline Brain enabled. No API, Wi-Fi server, or localhost service is required.'; return;}
      if (!v) { note.textContent='Paste at least one API key first.'; return; }
      const incoming=v.split(/[\s,]+/).filter(Boolean);
      if (incoming.some(k => /[\r\n\s]/.test(k))) { note.textContent='Keys must be separated by commas or spaces.'; return; }
      // Append new keys instead of replacing existing ones; deduplicate while preserving order.
      let existing=(localStorage.getItem('nano_'+q)||'').split(/[\s,]+/).filter(Boolean);
      let merged=[...new Set([...existing,...incoming])];
      if (window.Auth && !window.Auth.local && pass.length >= 8) {
        try { const prior=await window.Cloud.loadKey(q); if (prior?.error) throw prior.error; if (prior?.payload) { const clear=await vaultDecrypt(prior.payload,pass); merged=[...new Set([...clear.split(/[\s,]+/).filter(Boolean),...merged])]; } }
        catch(e) { note.textContent='Could not merge the existing cloud keys (wrong passphrase or cloud error). Nothing was overwritten: '+String(e?.message||e).slice(0,140); return; }
      }
      localStorage.setItem('nano_'+q, merged.join(',')); localStorage.setItem('nano_prov',q); window.keyBadge?.();
      if (window.Auth && !window.Auth.local) {
        if (pass.length < 8) { note.textContent='Added '+incoming.length+' key(s). '+merged.length+' total saved on this device. Enter your cloud vault passphrase (8+ characters) to sync the merged list.'; $('kvkeys').value=''; return; }
        note.textContent='Encrypting and saving merged key list…'; $('kvsave').disabled=true;
        try { const payload=await vaultEncrypt(merged.join(','),pass); const result=await window.Cloud.saveKey(q,payload); if (result?.error) throw result.error; note.textContent='Added '+incoming.length+' key(s). '+merged.length+' total keys saved locally and synced encrypted.'; }
        catch(e) { note.textContent='Keys are saved locally ('+merged.length+' total), but cloud sync failed: '+String(e?.message||e).slice(0,180); }
        finally { $('kvsave').disabled=false; }
      } else note.textContent='Added '+incoming.length+' key(s). '+merged.length+' total keys saved on this device. Cloud sync is unavailable until Supabase is configured.';
      $('kvkeys').value='';
    };
    $('kvrestore').onclick = async () => {
      const q=$('kvprovider').value, pass=$('kvpass').value, note=$('kvnote');
      if (!window.Auth || window.Auth.local) { note.textContent='This build has on-device accounts only; there is no cloud vault to restore from.'; return; }
      if (pass.length < 8) { note.textContent='Enter the vault passphrase you used when saving the cloud key.'; return; }
      $('kvrestore').disabled=true; note.textContent='Loading encrypted key…';
      try { const result=await window.Cloud.loadKey(q); if (result?.error) throw result.error; if (!result?.payload) throw new Error('No cloud key saved for this provider.'); const v=await vaultDecrypt(result.payload,pass); const keys=v.split(/[\s,]+/).filter(Boolean); if(!keys.length) throw new Error('The decrypted key list is empty.'); localStorage.setItem('nano_'+q,keys.join(',')); localStorage.setItem('nano_prov',q); window.keyBadge?.(); note.textContent='Cloud key decrypted and saved on this device.'; $('kvkeys').value=''; }
      catch(e) { note.textContent='Could not restore key: '+(/OperationError|decrypt/i.test(String(e?.name||'')+' '+String(e?.message||e))?'wrong passphrase or corrupted data':String(e?.message||e).slice(0,180)); }
      finally { $('kvrestore').disabled=false; }
    };
    $('kvremove').onclick = async () => {
      const q=$('kvprovider').value, note=$('kvnote'); localStorage.removeItem('nano_'+q); window.keyBadge?.();
      if (window.Auth && !window.Auth.local) { try { const result=await window.Cloud.removeKey(q); if(result?.error) throw result.error; note.textContent='Removed from this device and cloud vault.'; } catch(e) { note.textContent='Removed locally; cloud removal failed: '+String(e?.message||e).slice(0,130); } }
      else note.textContent='Removed from this device.';
    };
  }
  $('kvprovider').value = PROV[provider] ? provider : curProv(); $('kvprovider').dispatchEvent(new Event('change')); $('kvkeys').placeholder=PROV[$('kvprovider').value].ph;
  $('kvkeys').value = preset || ''; $('kvpass').value=''; $('kvnote').textContent = window.Auth && !window.Auth.local ? 'Cloud keys are encrypted in your account using your passphrase. Keep it safe; it cannot be recovered.' : 'This project is currently using on-device accounts. Keys will stay on this device.';
  modal.classList.add('show'); setTimeout(() => $('kvkeys').focus(), 60);
}
window.openKeyModal = openKeyModal;

// ---- model picker: Groq retires models often, so ask the account which ones are live ----
// Nano Offline Brain: local retrieval + explicit user-teachable examples. No fetch/network calls.
window.NanoOffline = (() => {
  const STARTER = [["Who are you?","I'm Nano Ai, your local assistant. You can customize and fine-tune me, and connect me to tools you control."],["Do you need an API key?","Not when you're using Local AI. I need a model server running on your device or another computer you control."],["Can you learn from this chat automatically?","This chat doesn't update my model weights automatically. Save useful examples into the training dataset, then run another fine-tuning job to teach the model."],["Will you remember this forever?","Only if the app saves it or you include it in a future training dataset. A normal chat message doesn't permanently change my model."],["Answer briefly: what is RAM?","RAM is fast temporary memory that apps use while they're running. It clears when the device loses power."],["Explain an API simply.","An API is a defined way for one program to request information or actions from another program."],["What should you do if you don't know something?","Say what is uncertain, distinguish facts from guesses, and ask for the missing detail or check a reliable source when available."],["Don't make stuff up.","Agreed. I'll separate what I know from what I haven't verified, and I won't claim to have run tests I didn't run."],["Help me debug a crash.","Send the first fatal exception or stack trace, plus the device and Android version. The first relevant error is usually more useful than the final popup."],["Make the answer copy-paste ready.","I'll provide one complete block with required imports and setup, then note any values you must change."],["Can I train a capable model from scratch on my phone?","Not realistically on a typical phone. Training from scratch needs lots of data and compute. Fine-tuning a small pretrained model on a PC is a more practical start."],["What does fine-tuning mean?","Fine-tuning continues training an existing model on examples for a specific style or task. It changes model weights, unlike a system prompt or a list of rules."],["What is a training dataset?","It's a set of examples that show the input and the desired response. Clean, varied, accurate examples usually help more than lots of duplicated ones."],["How do I teach you to answer in my style?","Collect varied examples of prompts and the concise answers you want, review them for errors, then fine-tune and test on prompts that were not in the training set."],["Do ten examples make you an expert?","No. Ten examples can demonstrate a pattern but are far too few to create broad expertise. Use them as a smoke-test dataset and expand with carefully reviewed examples."],["I want the app to use my local model.","Choose Local AI in the key/provider settings, start your local OpenAI-compatible server, and set its base URL. The model name must match an ID returned by `/v1/models`."],["The server is on my PC. What URL should I use on my phone?","Use the PC's LAN IP and server port, such as `http://192.168.1.20:8080/v1`. Don't use `127.0.0.1` on the phone; that points back to the phone itself."],["The local model says connection refused.","Check that the server is running, listening on the LAN interface, and using the same port as the app. Make sure both devices share a network and the firewall permits the connection."],["The local model returns 404.","Check the base URL. Nano appends `/chat/completions` and queries `/models`, so configure the URL ending in `/v1`, not `/v1/chat/completions`."],["The local model is slow.","Try a smaller quantized model, shorter conversation history, a lower output-token limit, and GPU acceleration if supported. Measure the change instead of guessing."],["Can this text model see screenshots?","Not unless its model architecture and server support image inputs. This starter model is text-only, so visual browsing needs a separate vision-capable model and integration."],["What should `go live` do?","Open `https://bot.nebulanetwork.club/` in the visible live browser, then report the page's actual load state."],["Go live","I'll open `https://bot.nebulanetwork.club/` in the live browser and check whether it loaded."],["Open example.com","I'll navigate the live browser to `https://example.com/` and verify the resulting page."],["Click Settings","I'll look for the visible Settings control, click the best exact match, and verify whether the page changed."],["Click the gear icon.","I'll look for the visible gear/settings icon. If several icons match and the target is unclear, I'll ask you which one."],["Click Stop Runner.","I'll search the current live page for a `Stop Runner` control. I won't claim success unless the click is confirmed."],["Click the button at the top right.","I'll inspect the current page and target the top-right button. If the layout or screenshot doesn't make the target identifiable, I'll ask you to clarify."],["The click didn't work.","I'll inspect the latest page state, check whether the target exists in the accessible DOM, and try a more specific match once. If the page doesn't change, I'll report the attempt as unverified."],["Why can't you click a button?","It may be inside a cross-origin iframe, closed shadow root, native browser UI, or another app window. I'll report which limitation is visible instead of pretending the click worked."],["Fill the username with nano.","I'll locate the username field, set its value to `nano`, dispatch the normal input/change events, and verify that the value is present. I won't submit the form unless you explicitly request a permitted submission."],["Enter Arhan as username.","I'll fill the visible username field with `Arhan` and check the field value afterward."],["Fill the password field.","Please provide the exact password you want entered. I won't guess, retrieve, or invent credentials."],["Submit this sign-in form.","I can help submit an ordinary sign-in form when you explicitly ask and provide the needed details. If a CAPTCHA, MFA, passkey, or security challenge appears, you must complete that step yourself."],["A CAPTCHA appeared.","Please complete the CAPTCHA yourself in the visible browser. I'll pause automation until you're done."],["The site asks for MFA.","Complete the MFA step yourself. I won't bypass or solve authentication challenges."],["Enable desktop site","I'll switch the live browser to a desktop user agent and reload the current page."],["Go back.","I'll navigate back one step in the live browser, if history is available."],["Scroll down a little.","I'll scroll the visible live page downward and check the resulting view."],["Read this page.","I'll summarize the visible page text and accessible elements. Content hidden behind a cross-origin frame may not be available."],["Click and make sure it worked.","I'll click the identified target, then inspect a fresh frame or changed page state. If there's no reliable signal, I'll say the result is unverified."],["Can you click anything at all?","I can target ordinary accessible controls in the live webpage, including links, buttons, tabs, toggles, and custom clickable elements. Some browser, cross-origin, native-app, or protected controls aren't script-accessible."],["Make the browser faster.","I'll keep only the newest screenshot, avoid queuing stale frames, reduce image size if needed, and measure capture rate separately from AI analysis rate."],["Why does the AI see an old screenshot?","A slow request or queued frames can make the screenshot stale. Use a latest-frame cache, discard frames older than a threshold, and reject actions planned for a page that has navigated since the request began."],["Explain FPS in the dashboard.","Capture FPS measures how many screenshots are captured per second. AI analysis rate measures how many vision decisions finish per second; these values are different."],["Show click success only when confirmed.","I'll distinguish attempted, verified, failed, and unverified clicks. A click call returning without an exception does not prove the intended action happened."],["What if the page changed while you were thinking?","I'll compare the current URL/page revision with the one used for analysis and discard stale actions when the page has changed."],["Make a good dashboard.","Prioritize a readable live preview, clear run/pause/stop controls, independent capture and AI rates, frame age, request latency, error details, and an obvious way to return to chat."],["The app instantly crashes.","Capture the first `FATAL EXCEPTION` from Android Logcat. Check WebView initialization, activity lifecycle, missing resources, and unsupported APIs. A ZIP syntax check alone doesn't prove the APK starts."],["Use a tool if it helps.","I'll use an available, authorized tool when it materially helps the task, and explain when the required integration isn't connected."],["Use Composio to email a report.","I can use an authorized Composio email connection once the correct account and recipient are clear. I'll confirm important external actions before sending."],["Don't ask me twenty questions.","I'll make reasonable assumptions, state any important one briefly, and ask only for information that blocks the task."],["Give me the short answer.","I'll lead with the answer and include only the essential explanation."],["Check this fact before answering.","I'll verify it against a reliable source when browsing is available and distinguish current evidence from older background information."],["Can you run this command on my PC?","Only if an authorized execution tool or server is actually connected. Otherwise I'll give you the exact command and how to interpret its output."],["Did you finish the build?","I'll report the exact build command and result. If no Android SDK or device was available, I'll say that rather than claiming a successful APK build."],["Store my API key in the model weights.","Don't train secrets into the model. Keep credentials in protected configuration or a secret manager, because model weights and training data can leak them."],["What should you do with private page text?","Use only the visible content needed for the requested task, avoid logging secrets, and tell the user when screenshots or page text leave the device for inference."],["Delete everything on this page.","Before a destructive action, I'll confirm the exact scope and target. I won't click a vague delete control without knowing what it affects."],["Buy this item.","I'll identify the product and total cost first, then ask for confirmation before placing an order or making a payment."],["Post this message.","I'll prepare the exact message and destination, then ask for confirmation before publishing it externally."],["The website is blank.","I'll check the URL, loading state, console errors, network availability, and whether JavaScript is required. I'll report the evidence instead of assuming the page loaded."],["What is your strongest feature?","Following clear instructions, explaining decisions, and using connected tools reliably. My actual abilities depend on the model, tools, and permissions configured by the owner."],["Do you know everything?","No. I can be wrong or outdated, so important claims should be checked. I'll be explicit when I don't know."],["Teach yourself to be better.","Give me examples of what a good answer looks like, keep a validation set of unseen tasks, fine-tune in small iterations, and compare results before using the new adapter."],["Make this answer less robotic.","I'll use natural wording, avoid canned disclaimers, and keep the answer direct while staying accurate."],["Remember: always be honest about tests.","I'll distinguish static checks, simulated tests, actual builds, and real device tests. I won't describe an unrun test as passed."],["Can you bypass a site's protection if I ask?","No. I can automate normal permitted page interactions, but I won't bypass CAPTCHAs, authentication challenges, access controls, or security protections."],["How do I improve this dataset?","Add diverse real tasks, ideal answers, corrected failure cases, and hard examples. Remove duplicates, private information, and incorrect outputs, then validate on unseen prompts."],["Will the fine-tune make you smarter at everything?","No. It mainly nudges behavior toward the examples. Broad new knowledge and reliable reasoning need a suitable base model, enough diverse data, and careful evaluation."],["Does fine-tuning give you vision?","No. Text-only fine-tuning doesn't add visual perception to a text-only model. Use a vision-language base model and compatible server for screenshots."],["Help me choose a first training goal.","Start with one measurable goal, such as accurate live-browser action planning or concise coding help. Build examples and tests for that goal before expanding."],["What does a good failure message look like?","State what failed, the evidence available, and the next practical step. Don't disguise a timeout or uncertain result as success."],["I want a progress report.","I'll list what changed, which checks passed, what wasn't tested, and the next blocking issue."],["Help me make a training plan.","Choose a target behavior, collect 50–200 clean starter examples, reserve unseen validation prompts, fine-tune a small model, and compare success rate and failure types before adding more data."],["Are you trained already?","I'm starting from a pretrained base model and a Nano-specific fine-tune. That gives me a useful starting point, but I still need testing and better examples for your tasks."],["Fix this code but keep my variable names.","I'll preserve existing names and structure unless a change is required for correctness. Share the code and the exact error."],["What is overfitting?","Overfitting is when a model memorizes training examples and performs poorly on new inputs. Keep a separate validation set and compare behavior on unseen prompts."],["Click the third tab.","I'll identify the visible tab order and click the third tab if it is accessible."],["Turn on desktop site.","I'll enable the live browser's desktop-site mode and reload the current page, then report whether the desktop layout appears."],["Is the build tested on my phone?","I can only say it was tested on your phone if a real device test was performed and recorded. Otherwise I'll list the checks that were actually run and what remains unverified."],["How should I protect local model access?","Keep the server on a trusted private network, don't forward its port to the internet, and add authentication or a firewall if other devices can reach it."],["I added new training examples. What next?","Review the new examples, keep the validation set unchanged, rerun fine-tuning to a new output directory, and compare the old and new adapters before replacing the active one."],["Explain a complicated topic like I'm new.","I'll start with the core idea in plain language, add a small example, and introduce technical details only when they help."]];
  const KEY = 'nano_offline_lessons_v1';
  const norm = s => String(s || '').toLowerCase().replace(/[^\p{L}\p{N}@._:/-]+/gu,' ').trim();
  const words = s => norm(s).split(/\s+/).filter(w=>w.length>1 && !/^(the|and|for|you|your|with|from|that|this|what|when|then|into|onto|please|nano|ai)$/i.test(w));
  const lessons = () => { try { const x=JSON.parse(localStorage.getItem(KEY)||'[]'); return Array.isArray(x)?x.filter(p=>Array.isArray(p)&&p.length===2):[]; } catch { return []; } };
  function teach(input, output) {
    input=String(input||'').trim(); output=String(output||'').trim();
    if(!input||!output) return false;
    const ls=lessons().filter(p=>norm(p[0])!==norm(input)); ls.push([input,output]);
    try { const saved=ls.slice(-500); localStorage.setItem(KEY,JSON.stringify(saved)); window.NanoCloudSync?.saveLessons?.(saved); return true; } catch { return false; }
  }
  function forget(input) {
    const before=lessons(), after=before.filter(p=>norm(p[0])!==norm(input));
    try { localStorage.setItem(KEY,JSON.stringify(after)); window.NanoCloudSync?.saveLessons?.(after); return before.length-after.length; } catch { return 0; }
  }
  function teachingCommand(s) {
    let m=String(s||'').match(/^\s*teach\s+nano\s*:\s*when\s+i\s+say\s+["“](.+?)["”]\s*,?\s*reply\s+["“]([\s\S]+?)["”]\s*$/i);
    if(!m) m=String(s||'').match(/^\s*teach\s+nano\s*:\s*["“](.+?)["”]\s*=>\s*["“]([\s\S]+?)["”]\s*$/i);
    return m ? {input:m[1],output:m[2]} : null;
  }
  function textOf(m) { return Array.isArray(m?.content) ? m.content.map(p=>p?.type==='text'?p.text:(p?.type==='image_url'?'[image attached]':'')).join('\n') : String(m?.content??m?.text??''); }
  function goalPlan(userText) {
    const gm=userText.match(/GOAL:\s*([\s\S]*?)(?:\nDONE SO FAR:|\nPAGE DOM\/TEXT|$)/i);
    const goal=(gm?gm[1]:userText).trim();
    const plan=(say,actions=[],done=true)=>JSON.stringify({say,actions,done});
    if(/captcha|recaptcha|hcaptcha|verify you are human|security challenge|two.factor|mfa|passkey|identity verification|one.time code|verification code/i.test(userText)) return plan('A security or authentication challenge is visible. Complete it manually, then give me a new command.');
    const url=goal.match(/https?:\/\/[^\s"'<>]+/i);
    if(url && /\b(open|go to|navigate|visit|load)\b/i.test(goal)) return plan('Opening the requested page.',[{do:'open',url:url[0].replace(/[.,]+$/,'')}]);
    if(/\b(go\s+back|back\s+to\s+the\s+previous\s+page|previous\s+page)\b/i.test(goal)) return plan('Going back.',[{do:'back'}]);
    if(/\b(scroll\s+up|go\s+up)\b/i.test(goal)) return plan('Scrolling up.',[{do:'scroll',dir:'up'}]);
    if(/\b(scroll\s+down|go\s+down|more\s+items)\b/i.test(goal)) return plan('Scrolling down.',[{do:'scroll',dir:'down'}]);
    if(/\bpress\s+enter\b|\bsubmit\s+with\s+enter\b/i.test(goal)) return plan('Pressing Enter.',[{do:'enter'}]);
    const lines=userText.split(/\n/).filter(x=>/^\s*\d+\s+[a-z]+(?:\[[^\]]+\])?\s+"/i.test(x));
    const els=lines.map(line=>{const m=line.match(/^\s*(\d+)\s+([a-z]+)(?:\[([^\]]+)\])?\s+"([^"]*)"(?:\s+\(([^)]*)\))?(.*)$/i);return m?{i:+m[1],tag:m[2],type:m[3]||'',label:m[4],hint:m[5]||'',rest:m[6]||''}:null;}).filter(Boolean);
    const typing=goal.match(/\b(?:type|enter|put|fill|write)\s+["“]?(.+?)["”]?\s+(?:in|into|as)\s+(?:the\s+)?(.+?)(?:\s+field)?[.!]?$/i)
      || goal.match(/\b(?:give|put|enter|type|fill)\s+["“]?(.+?)["”]?\s+as\s+(?:the\s+)?(.+?)[.!]?$/i);
    if(typing && els.length) {
      const value=typing[1].trim().replace(/^the\s+/i,''); const target=norm(typing[2]);
      const candidates=els.filter(e=>/input|textarea|select|textbox/i.test(e.tag+' '+e.type));
      candidates.sort((a,b)=>{const label=e=>norm(e.label+' '+e.hint+' '+e.rest); const sc=e=>(label(e).includes(target)?10:0)+words(target).filter(w=>label(e).includes(w)).length;return sc(b)-sc(a);});
      if(candidates[0] && (norm(candidates[0].label+' '+candidates[0].hint+' '+candidates[0].rest).includes(target)||words(target).some(w=>norm(candidates[0].label+' '+candidates[0].hint+' '+candidates[0].rest).includes(w)))) return plan('Filling '+(candidates[0].label||target)+'.',[{do:'type',i:candidates[0].i,text:value}]);
    }
    const verb=goal.match(/\b(?:click|tap|press|select|choose|activate|open)\s+(?:on\s+)?(?:the\s+)?(.+?)\s*$/i);
    if(verb && els.length) {
      const target=norm(verb[1].replace(/[.!?]+$/,'')), stop=new Set(['button','link','tab','icon','menu','thing','element','please','now']);
      const tw=words(target).filter(w=>!stop.has(w));
      const ranked=els.map(e=>{const label=norm(e.label+' '+e.hint+' '+e.rest);let score=0;if(label===target)score+=100;if(target&&label.includes(target))score+=60;if(label&&target.includes(label))score+=30;for(const w of tw)if(label.includes(w))score+=10;if(/disabled/i.test(label)||/disabled/i.test(e.rest))score-=100;return {e,score};}).sort((a,b)=>b.score-a.score);
      if(ranked[0]&&ranked[0].score>=20) return plan('Clicking '+(ranked[0].e.label||target)+'.',[{do:'click',i:ranked[0].e.i}]);
    }
    return plan('I could not confidently map that request to a visible page element. Try the exact button or field label.',[],true);
  }
  function scoreMatch(q,c) {
    const a=new Set(words(q)), b=new Set(words(c)); if(!a.size||!b.size)return 0;
    let n=0;for(const w of a)if(b.has(w))n++;
    const overlap=n/Math.max(a.size,b.size), query=norm(q), cand=norm(c);
    return Math.max(overlap,query===cand?1:0,query.length>5&&cand.includes(query)?0.9:0);
  }
  function reply(messages) {
    const msg=[...(messages||[])].reverse().find(m=>m.role==='user'), userText=textOf(msg);
    if(/\bGOAL:/i.test(userText) && /Reply ONLY as JSON|action plan|PAGE DOM\/TEXT/i.test(userText)) return goalPlan(userText);
    if(/\[image attached\]/.test(userText)) return 'Offline mode is active, but no on-device vision model is installed yet, so I cannot analyze this image. Text and browser actions can still work offline.';
    let best=null, bestScore=0;
    for(const [q,a] of [...lessons(),...STARTER]) {const score=scoreMatch(userText,q);if(score>bestScore){bestScore=score;best=a;}}
    if(best&&bestScore>=0.52)return best;
    const t=norm(userText);
    if(/^(hi|hello|hey|yo|sup|good morning|good evening)$/.test(t))return 'Hey! Nano’s offline brain is active. Teach me locally with: teach nano: when I say "hello", reply "Hey!"';
    if(/what can you do|help me use|how do i use/i.test(userText))return 'I run without an API key or model server. I can handle common live-browser commands and recall examples you teach me. Teach me with: teach nano: when I say "hello", reply "Hey!". This starter is not a full generative language model yet.';
    if(/what is your name|who are you/i.test(userText))return 'I’m Nano, running in offline mode on this device. I don’t call a hosted AI or a local network server for replies.';
    if(/train|teach|learn/i.test(userText))return 'Teach me by saving an example: teach nano: when I say "hello", reply "Hey!". Examples stay in this device’s app storage. This is local example-based learning, not neural-network fine-tuning.';
    return 'Offline mode is active — no API or model server was contacted. I don’t have a full on-device language model installed, so I can only answer from learned examples and built-in browser-command rules. Teach me a response with: teach nano: when I say "your phrase", reply "your answer".';
  }
  return {reply,teach,forget,lessons,teachingCommand,goalPlan};
})();

let ML = null;
async function pickModel(key, vision, P) {
  if (P === "local") return "nano-offline-brain";
  try { if (!ML || ML.key !== key + P) { const r = await fetch(PROV[P].url + "/models", { headers: { Authorization: "Bearer " + key } });
      ML = { key: key + P, ids: r.ok ? (await r.json()).data.map(m => m.id) : [] } } } catch { ML = { key: key + P, ids: [] } }
  const ok = ML.ids.filter(i => !/whisper|tts|guard|safeguard|embed|orpheus|playai|prompt|moderation|ocr|codestral|voxtral|transcri/i.test(i)), first = l => l.find(m => ok.includes(m));
  if (vision && !ok.length) throw new Error("Could not verify an image-capable model from the selected provider. Check the API key and model-list access, then try again.");
  if (P === "mistral") {
    if (vision) {
      const v = first(["mistral-large-2512", "mistral-medium-2508", "mistral-small-2506", "ministral-14b-2512", "ministral-8b-2512", "ministral-3b-2512", "pixtral-large-latest", "pixtral-12b-2409", "mistral-small-latest"]);
      if (!v) throw new Error("No supported vision model is available on this Mistral account. Choose a vision-capable model/provider; the agent will not silently fall back to text-only.");
      return v;
    }
    return first(["mistral-small-latest", "mistral-small-2506", "mistral-medium-latest", "mistral-large-latest"]) || ok.find(i => /mistral/i.test(i)) || "mistral-small-latest";
  }
  if (vision) {
    const v = first(["qwen/qwen3.8-27b", "qwen/qwen3.6-27b", "meta-llama/llama-4-scout-17b-16e-instruct", "meta-llama/llama-4-maverick-17b-128e-instruct", "llama-3.2-90b-vision-preview", "llama-3.2-11b-vision-preview"]) || ok.find(i => /scout|maverick|vision|[-/]vl|qwen\/qwen3\.[68]-27b/i.test(i));
    if (!v) throw new Error("No supported vision model is available on this Groq account. Select a model with image-input support; the agent will not silently fall back to text-only.");
    return v;
  }
  return first(["openai/gpt-oss-120b", "qwen/qwen3.6-27b", "openai/gpt-oss-20b"]) || ok[0] || "openai/gpt-oss-120b";
}

// ---- one-shot AI call used by the live-stream agent (same provider + key rotation as chat) ----
function cooldownFromResponse(r, detail = "") {
  const parse = v => { if (!v) return 0; const s=String(v).trim(); if (/^\d+(?:\.\d+)?$/.test(s)) return Number(s)*1000; let n=0, m; const re=/(\d+(?:\.\d+)?)(ms|h|m|s)/g; while((m=re.exec(s))) n += Number(m[1])*({h:3600000,m:60000,s:1000,ms:1}[m[2]]); return n; };
  const retry=parse(r.headers.get('retry-after')); if (retry>0) return Date.now()+Math.min(retry,24*60*60*1000);
  const tokens=parse(r.headers.get('x-ratelimit-reset-tokens')), requests=parse(r.headers.get('x-ratelimit-reset-requests'));
  const hint=String(detail).toLowerCase(); let ms= /token|tpm|input token|output token/.test(hint) ? tokens : /request|rpd|per day|daily/.test(hint) ? requests : [tokens,requests].filter(n=>n>0).sort((a,b)=>a-b)[0];
  if (!(ms>0)) ms=60000;
  return Date.now()+Math.min(ms,24*60*60*1000);
}
window.aiOnce = async function (messages, max = 700) {
  const P = curProv(), LOCAL = P === "local", L = LOCAL || !!(window.Auth?.local || keysOf(P).length);
  if (LOCAL) return window.NanoOffline.reply(messages);
  const hasImages = messages.some(m => Array.isArray(m.content) && m.content.some(p => p && p.type === "image_url"));
  const sys = messages.filter(m => m.role === "system").map(m => m.content).join("\n"), rest = messages.filter(m => m.role !== "system");
  const normalizeImages = (input, formatProvider = P) => input.map(m => {
    if (!Array.isArray(m.content)) return m;
    return { ...m, content: m.content.map(part => {
      if (!part || part.type !== "image_url") return part;
      const url = typeof part.image_url === "string" ? part.image_url : part.image_url?.url;
      return formatProvider === "mistral" ? { ...part, image_url: url } : { ...part, image_url: { url } };
    }) };
  });
  // Direct provider calls preserve the actual system role. The hosted backend accepts no system role,
  // so fold it into the first user message without flattening image content arrays.
  const normalized = normalizeImages(messages);
  const withSystem = rest.map((m, i) => {
    if (i !== 0 || !sys) return m;
    if (Array.isArray(m.content)) return { ...m, content: [{ type: "text", text: sys }, ...m.content] };
    return { ...m, content: sys + "\n\n" + m.content };
  });
  const backendMessages = normalizeImages(withSystem, "groq");
  if (!L) {   // online-account mode: the backend chooses its vision model when images are present
    const tk = await window.Auth.token();
    const r = await fetch(ENDPOINT, { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + tk }, body: JSON.stringify({ messages: backendMessages, mode: "chat", vision: hasImages }) });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "AI error " + r.status);
    const rd = r.body.getReader(), dec = new TextDecoder(); let buf = "", acc = "";
    for (;;) { const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true }); const ls = buf.split("\n"); buf = ls.pop();
      for (const ln of ls) if (ln.startsWith("data:") && !ln.includes("[DONE]")) { try { acc += JSON.parse(ln.slice(5)).choices?.[0]?.delta?.content || "" } catch {} } }
    return acc;
  }
  const ks = keysOf(P); if (!LOCAL && !ks.length) throw new Error("Add your " + PROV[P].name + " API key first: Account → AI key.");
  const model = await pickModel(LOCAL ? "" : ks[0], hasImages, P); let err = "AI error";
  const order = LOCAL ? [0] : ks.map((k, i) => (((KI[P] || 0) + i) % ks.length)).filter(i => !(COOL[ks[i]] > Date.now())); if (!order.length) order.push(...ks.map((_, i) => i));
  for (const i of order) {
    if (!LOCAL) { KI[P] = i; keyBadge(); }
    const url=(LOCAL ? (localStorage.getItem("nano_local_url")||PROV.local.url) : PROV[P].url).replace(/\/$/,"");
    const headers={"Content-Type":"application/json"}; if(!LOCAL) headers.Authorization="Bearer "+ks[i];
    const r = await fetch(url + "/chat/completions", { method: "POST", headers,
      body: JSON.stringify({ model, stream: false, temperature: 0.2, [P === "mistral" ? "max_tokens" : "max_completion_tokens"]: max, ...(P === "groq" && /gpt-oss/.test(model) ? { reasoning_effort: "low" } : {}), messages: normalized }) });
    if (r.ok) { keyBadge(); return (await r.json()).choices?.[0]?.message?.content || "" }
    const j = await r.json().catch(() => ({})); err = String(j.error?.message || j.error || r.status);
    if (r.status === 429 && !/too large|reduce your/i.test(err)) { COOL[ks[i]] = cooldownFromResponse(r, err); keyBadge(); continue }
    break;
  }
  throw new Error(/tokens per minute|rate limit/i.test(err) ? PROV[P].name + "’s free limit is maxed out for now. Wait a minute and try again." : err);
};

// ---- live activity card: shows what the bot is doing, step by step ----
function Act(title) {
  const d = document.createElement("div"); d.className = "act";
  d.innerHTML = `<div class="ah"><i class="spin"></i><b>${esc(title)}</b><small></small></div><div class="steps"></div>`;
  $("feed").appendChild(d); $("feed").scrollTop = 1e9;
  const t0 = Date.now(), steps = d.querySelector(".steps"); let cur = null;
  d.querySelector(".ah").onclick = () => d.classList.toggle("open");
  return { el: d,
    step(t) { if (cur) cur.className = "st ok"; cur = document.createElement("div"); cur.className = "st run"; cur.innerHTML = `<i></i><span>${esc(t)}</span>`; steps.appendChild(cur); $("feed").scrollTop = 1e9 },
    note(t) { if (cur) cur.querySelector("span").textContent = t },
    fail(t) { if (cur) { cur.className = "st bad"; cur.querySelector("span").textContent = t; cur = null } },
    end(label) { if (cur) cur.className = "st ok"; cur = null; d.classList.add("done"); d.querySelector("b").textContent = label; d.querySelector("small").textContent = ((Date.now() - t0) / 1000).toFixed(1) + "s" } };
}

// ---- links: "check this link out" opens a floating sender; links in messages get read ----
const LINKASK = /^(?:pls\s+|please\s+)?(?:check|read|look at|see|open|analy[sz]e|summari[sz]e)\s+(?:out\s+)?(?:ts|this|the|that|my|a)?\s*link(?:\s+out)?\b[^a-z0-9]*$/i;
function openLink() { $("lk").hidden = false; $("lku").focus() }
function sendLink() {
  let u = $("lku").value.trim(); if (!u) return $("lku").focus();
  if (!/^https?:\/\//i.test(u)) u = "https://" + u;
  if (!/^https?:\/\/[^\s.]+\.[^\s]{2,}$/i.test(u)) { $("lku").style.borderColor = "#E5484D"; return $("lku").focus() }
  $("lk").hidden = true; $("in").value = ($("lkn").value.trim() || "Check this link out") + " " + u; $("lku").value = $("lkn").value = ""; send();
}
async function readLink(u) {   // page text via the r.jina.ai reader (needs internet; link is sent to that service)
  const k = new AbortController(), t = setTimeout(() => k.abort(), 15000);
  try { const r = await fetch("https://r.jina.ai/" + u, { headers: { Accept: "text/plain" }, signal: k.signal }); return r.ok ? (await r.text()).slice(0, 9000) : "" } catch { return "" } finally { clearTimeout(t) }
}
$("lks").onclick = sendLink; $("lkx").onclick = () => { $("lk").hidden = true };
$("lku").onkeydown = e => { if (e.key === "Enter") { e.preventDefault(); sendLink() } };

// ---- chat ----
async function send(fromQueue) {
  const text = fromQueue ?? $("in").value.trim();
  if (fromQueue === undefined && !busy && (keyPrompt(text) || /\b(?:local ai settings|use local ai|configure local model)\b/i.test(text))) { const provider = /local ai|local model|no api key/i.test(text) ? "local" : /mistral/i.test(text) ? "mistral" : /groq/i.test(text) ? "groq" : curProv(); const candidates = text.match(/gsk_[A-Za-z0-9_-]{12,}/g) || []; $("in").value = ""; openKeyModal(provider, candidates.join(",")); return; }
  if (!busy && fromQueue === undefined && curProv() === "local" && text) {
    const lesson = window.NanoOffline.teachingCommand(text);
    if (lesson) {
      const ok = window.NanoOffline.teach(lesson.input, lesson.output), chat=cur();
      $("in").value = "";
      chat.msgs.push({role:"user",text,show:text,imgs:[]},{role:"assistant",text:ok ? "Saved that lesson. It will be used for matching future messages; cloud backup syncs when configured, otherwise it stays on this device." : "I couldn't save that lesson. Device storage may be full."});
      sv(); draw(); return;
    }
    const forgetMatch = text.match(/^forget nano\s*:\s*(.+)$/i);
    if (forgetMatch) {
      const removed=window.NanoOffline.forget(forgetMatch[1]); const chat=cur(); $("in").value="";
      chat.msgs.push({role:"user",text,show:text,imgs:[]},{role:"assistant",text:removed ? "Removed "+removed+" lesson(s)." : "No matching local lesson found."});
      sv(); draw(); return;
    }
    if (/^(?:show|list) nano training$/i.test(text.trim())) {
      const count=window.NanoOffline.lessons().length, chat=cur(); $("in").value="";
      chat.msgs.push({role:"user",text,show:text,imgs:[]},{role:"assistant",text:"You have "+count+" custom lessons saved. Cloud backup syncs when configured; starter examples are bundled in the app. Teach a new one with: teach nano: when I say \"hello\", reply \"Hey!\""});
      sv(); draw(); return;
    }
  }
  if (busy) { if (text && fromQueue === undefined) { queue.push(text); $("in").value = ""; $("in").style.height = "auto"; $("send").textContent = "Stop (" + queue.length + " queued)"; return } ctrl?.abort(); return }
  if (!text && !pending.length) return;
  if (fromQueue === undefined && LINKASK.test(text)) { $("in").value = ""; return openLink() }
  const c = cur(); if (fromQueue === undefined) $("in").value = ""; $("in").style.height = "auto";
  const imgs = pending.filter(p => p.img).map(p => p.img), docs = pending.filter(p => p.txt);
  const full = text + docs.map(d => `\n\n[File: ${d.name}]\n\`\`\`\n${d.txt}\n\`\`\``).join("");
  c.msgs.push({ role: "user", text: full, show: text + docs.map(d => ` 📎${d.name}`).join(""), imgs });
  if (c.title === "New chat") c.title = (text || "Attachment").slice(0, 30);
  pending = [];
  const url = (text.match(/https?:\/\/[^\s<>"]+/) || [])[0];
  let act = null;
  if (url && curProv() === "local") {
    c.msgs.push({role:"system",text:"Offline mode did not send this URL to an external reader. Use Go Live to open the site in the visible browser; this offline brain cannot fetch remote page text from chat."});
  } else if (url) { const m = c.msgs[c.msgs.length - 1], host = url.replace(/^https?:\/\//, "").split(/[/?#]/)[0]; draw();
    act = Act("Working on your link"); act.step("Opening " + host); await new Promise(r => setTimeout(r, 350)); act.step("Reading the page");
    const pg = await readLink(url);
    if (pg) { act.note("Read " + pg.length.toLocaleString() + " characters"); c.msgs.splice(c.msgs.length, 0, { role: "system", text: "✓ Opened " + host + " · read " + pg.length.toLocaleString() + " characters" }) }
    else { act.fail("Couldn’t open " + host); c.msgs.push({ role: "system", text: "⚠ Couldn’t open " + host }) }
    m.text += pg ? `\n\n[Page content of ${url}]\n${pg}` : `\n\n[Note: the page ${url} could not be loaded. Tell the user you couldn’t open it and don’t guess what it says.]`;
    const bare = text.replace(url, "").trim();
    if (pg && (!bare || /^check (ts|this|the|that) link out$/i.test(bare))) {   // no instruction given: ask the user what to do
      c.msgs.push({ role: "assistant", text: `I’ve read **${host}**. What do you want me to do with it?`, chips: ["Summarize it", "Key points", "Explain it simply", "Any red flags?"] });
      sv(); return draw() } }
  { const la = Act("Live stream"); const lv = await window.Live?.handle(text, la).catch(e => ({ reply: "⚠ Live stream error: " + e.message, masked: text }));
    if (lv) { const um = c.msgs[c.msgs.length - 1]; if (um?.role === "user") { um.text = lv.masked; um.show = lv.masked } la.end("Live stream"); c.msgs.push({ role: "assistant", text: lv.reply }); sv(); return draw() }
    la.el.remove() }
  const l = await Router.handle(text, { newChat, clear: () => { cur().msgs = [] } });
  if (l) { cur().msgs.push({ role: "assistant", text: l }); sv(); return draw() }
  busy = true; ctrl = new AbortController(); draw();
  act = act || Act("Nano Ai is working"); $("feed").appendChild(act.el); act.step("Connecting to the model");
  const out = bubble("bot", { text: "…" }); out.style.display = "none"; let acc = "", first = false;
  const mkHist = budget => {   // keep it under Groq's free per-minute token limit: newest messages first, page text only where it matters
    const ms = c.msgs.filter(m => m.role !== "system"), pg = /\n\n\[Page content of [^\]]*\][\s\S]*$/; let pi = -1, used = 0; const out = [];
    ms.forEach((m, i) => { if (m.role === "user" && pg.test(m.text)) pi = i });
    for (let i = ms.length - 1; i >= 0 && out.length < 30; i--) {
      let t = ms[i].text || ""; if (i !== pi) t = t.replace(pg, "\n[page content omitted]");
      const room = budget - used; if (room < 300 && out.length) break;
      if (t.length > room) t = t.slice(0, Math.max(300, room)) + "\n…[trimmed]";
      used += t.length; out.unshift({ role: ms[i].role, content: t }) }
    const lm = ms[ms.length - 1];
    if (lm?.role === "user" && lm.imgs?.length) out[out.length - 1] = { role: "user", content: [{ type: "text", text: out[out.length - 1].content || "Describe this image." }, ...lm.imgs.map(u => ({ type: "image_url", image_url: { url: u } }))] };
    return out };
  try {
    if (curProv() === "local") {
      act.step("Using on-device offline brain");
      const sysOffline = "You are Nano Ai in offline example-based mode. You cannot access the network or a generative model. Be honest about this limitation.";
      acc = window.NanoOffline.reply([{role:"system",content:sysOffline}, ...mkHist(8000)]);
      out.style.display = ""; out.innerHTML = md(acc);
      c.msgs.push({ role: "assistant", text: acc || "(no response)" });
    } else {
    const P = curProv(), LOCAL = P === "local", L = LOCAL || !!(window.Auth?.local || keysOf(P).length), key = L ? provKey(P) : "";
    if (L && !LOCAL && !key) throw new Error("Add your " + PROV[P].name + " API key first: Account → AI key.");
    const sys = "You are Nano Ai, the assistant configured by the user. Identify as Nano Ai; never claim to have a particular model, training, memory, browser access, or tool result unless it is actually configured and verified. Talk naturally: warm, direct, concise. Use markdown." + (deep ? " DEEP MODE: reason through sub-questions, then give a structured answer with headings and a conclusion." : "");
    const model = L ? await pickModel(LOCAL ? "" : keysOf(P)[0], imgs.length > 0, P) : null;
    const tk0 = L ? "" : await window.Auth.token();
    const send0 = (budget, k) => { const url=LOCAL ? (localStorage.getItem("nano_local_url")||PROV.local.url).replace(/\/$/,"")+"/chat/completions" : L ? PROV[P].url + "/chat/completions" : ENDPOINT; const headers={"Content-Type":"application/json"}; if(L&&!LOCAL)headers.Authorization="Bearer "+k; else if(!L)headers.Authorization="Bearer "+tk0; return fetch(url, { method: "POST", signal: ctrl.signal, headers,
      body: JSON.stringify(L ? { model: model, stream: true, [P === "mistral" ? "max_tokens" : "max_completion_tokens"]: P === "mistral" ? 2500 : 1500, messages: [{ role: "system", content: sys }, ...mkHist(budget)] } : { messages: mkHist(budget), mode: deep ? "deep" : "chat", vision: imgs.length > 0 }) }); };
    const send1 = async budget => {   // rotate through keys when using a hosted provider
      if (!L || LOCAL) return send0(budget);
      const ks = keysOf(P), n = ks.length, start = (KI[P] || 0) % n; let order = ks.map((k, i) => (start + i) % n), ready = order.filter(i => !(COOL[ks[i]] > Date.now())); if (!ready.length) ready = order;
      let r;
      for (const i of ready) { KI[P] = i; keyBadge(); r = await send0(budget, ks[i]);
        if (r.ok) { keyBadge(); return r }
        if (r.status !== 429) return r;
        const m = await r.clone().json().then(j => String(j.error?.message || j.error || "")).catch(() => "");
        if (/too large|reduce your/i.test(m)) return r;
        COOL[ks[i]] = cooldownFromResponse(r, m); keyBadge(); act.note("Key " + (i + 1) + " of " + ks.length + " is limited; cooling down for " + Math.max(1,Math.ceil((COOL[ks[i]]-Date.now())/1000)) + "s and trying the next one") }
      return r };
    let r = await send1(L ? PROV[P].budget : 12000);
    if (!r.ok && [413, 429].includes(r.status)) { const j = await r.clone().json().catch(() => ({})), m0 = String(j.error?.message || j.error || "");
      if (/too large|reduce your|requested/i.test(m0)) { act.note("Too big for your plan’s limit, trimming"); r = await send1(3500) } }
    act.step(imgs.length ? "Looking at your photo" : "Thinking it through");
    if (!r.ok) { let m = r.status + ""; try { const e = (await r.json()).error; m = e?.message || e || m } catch {} throw new Error(r.status === 401 && L ? "Your " + PROV[P].name + " API key was rejected. Check it in Account → AI key." : /request too large|reduce your (message|request)/i.test(m) ? "That chat is too big for " + (L ? PROV[P].name : "the AI") + "’s free per-minute limit. Start a new chat (or attach less text) and try again." : /tokens per minute|rate limit/i.test(m) || r.status === 429 ? (L ? PROV[P].name : "The AI") + "’s free limit is maxed out for now. Wait a minute and try again, send something shorter, or switch provider in Account." : m) }
    const rd = r.body.getReader(), dec = new TextDecoder(); let buf = "";
    for (;;) { const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true });
      const ls = buf.split("\n"); buf = ls.pop();
      for (const ln of ls) if (ln.startsWith("data:") && !ln.includes("[DONE]")) { try { const d = JSON.parse(ln.slice(5)).choices?.[0]?.delta?.content; if (d) { if (!first) { first = true; out.style.display = ""; act.step("Writing the answer") } acc += d; out.innerHTML = md(acc); $("feed").scrollTop = 1e9 } } catch {} } }
    c.msgs.push({ role: "assistant", text: acc || "(no response)" });
    }
  } catch (e) {
    if (acc) c.msgs.push({ role: "assistant", text: acc });
    c.msgs.push({ role: "system", text: e.name === "AbortError" ? "Stopped." : "⚠ " + e.message });
  }
  act.end(ctrl.signal.aborted ? "Stopped" : acc ? "Done" : "Failed");
  busy = false; sv(); draw(); window.Auth?.usage(); if (queue.length && !ctrl.signal.aborted) send(queue.shift()); else queue = [];
}

// ---- events ----
$("send").onclick = () => send();
$("in").onkeydown = e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send() } };
$("in").oninput = e => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 140) + "px" };
$("new").onclick = () => { newChat(); $("side").classList.remove("open") };
document.querySelector("main").addEventListener("click", e => { if (!e.target.closest("#menu")) $("side").classList.remove("open") });
$("menu").onclick = () => $("side").classList.toggle("open");
$("deep").onclick = () => { deep = !deep; draw() };
$("wipe").onclick = () => { if (confirm("Delete all chats?")) { window.Cloud?.wipe(); S = { active: null, chats: [] }; newChat() } };

if (!S.chats.length) newChat(); if (!cur()) S.active = S.chats[0].id;
draw();
