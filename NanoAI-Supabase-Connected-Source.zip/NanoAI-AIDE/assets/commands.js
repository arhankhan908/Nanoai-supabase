// Tiny slash-command router: runs in your code before text reaches the AI.
window.Router = (() => {
  const HELP = "**Commands**\n- `/calc 2*(3+4)`\n- `/time`\n- `/new` · `/clear`";
  function calc(e) { e = e.replace(/\^/g, "**"); if (!/^[\d+\-*/().%\s*]+$/.test(e)) return "I can only calculate numbers and + - * / % ^ ( )."; try { const r = Function('"use strict";return(' + e + ")")(); return `${e} = **${r}**` } catch { return "That expression doesn’t work." } }
  async function handle(text, ctx = {}) {
    const t = text.trim(), low = t.toLowerCase();
    if (low === "/help") return HELP;
    if (low === "/new") { ctx.newChat?.(); return "Started a new chat." }
    if (low === "/clear") { ctx.clear?.(); return "Chat cleared." }
    if (low === "/time") return new Date().toLocaleString();
    if (low.startsWith("/calc ")) return calc(t.slice(6));
    return null; // not a command: goes to the AI
  }
  return { handle };
})();
