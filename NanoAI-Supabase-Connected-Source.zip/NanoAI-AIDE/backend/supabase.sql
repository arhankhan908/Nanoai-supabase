-- Run in Supabase > SQL Editor
create table profiles(id uuid primary key references auth.users on delete cascade, email text, is_admin boolean default false, banned boolean default false,
  daily_limit int default 50000, used int default 0, used_on date default current_date, accepted_at timestamptz, terms_version text);
create table chats(id text primary key, user_id uuid not null references auth.users on delete cascade, title text, msgs jsonb default '[]', pinned boolean default false, updated_at timestamptz default now());
alter table profiles enable row level security; alter table chats enable row level security;
create policy "read own profile" on profiles for select using (auth.uid() = id);   -- no update policy: users can't edit limits or admin flag
create policy "own chats" on chats for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into profiles(id,email,accepted_at,terms_version) values (new.id,new.email,(new.raw_user_meta_data->>'accepted_at')::timestamptz,new.raw_user_meta_data->>'terms_version'); return new; end $$;
create trigger on_signup after insert on auth.users for each row execute function handle_new_user();
create function add_usage(uid uuid, n int) returns void language sql security definer set search_path = public as $$
update profiles set used = case when used_on = current_date then used + n else n end, used_on = current_date where id = uid $$;
revoke execute on function add_usage(uuid,int) from public, anon, authenticated;
-- AFTER you sign up once in the app, make yourself admin (unlimited tokens):
-- update profiles set is_admin = true where email = 'YOUR_EMAIL_HERE';


-- Encrypted user API-key vault. The client encrypts secrets before upload;
-- this table stores ciphertext only, never a raw provider key.
create table if not exists api_key_vault(
  user_id uuid not null references auth.users on delete cascade,
  provider text not null check (provider in ('groq','mistral')),
  payload jsonb not null,
  updated_at timestamptz not null default now(),
  primary key(user_id, provider)
);
alter table api_key_vault enable row level security;
drop policy if exists "read own encrypted key vault" on api_key_vault;
drop policy if exists "manage own encrypted key vault" on api_key_vault;
create policy "manage own encrypted key vault" on api_key_vault for all using (auth.uid() = user_id) with check (auth.uid() = user_id);


-- Optional cloud backup for Nano's user-taught example lessons.
-- The app uses Supabase Anonymous Sign-ins and a separate auth storage key.
create table if not exists public.nano_ai_lessons (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_key text not null,
  trigger_text text not null check (char_length(trigger_text) between 1 and 500),
  response_text text not null check (char_length(response_text) between 1 and 2000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint nano_ai_lessons_user_lesson_key unique (user_id, lesson_key)
);
alter table public.nano_ai_lessons enable row level security;
grant select, insert, update, delete on public.nano_ai_lessons to authenticated;
drop policy if exists "Users can read their own Nano lessons" on public.nano_ai_lessons;
create policy "Users can read their own Nano lessons" on public.nano_ai_lessons
  for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "Users can add their own Nano lessons" on public.nano_ai_lessons;
create policy "Users can add their own Nano lessons" on public.nano_ai_lessons
  for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists "Users can update their own Nano lessons" on public.nano_ai_lessons;
create policy "Users can update their own Nano lessons" on public.nano_ai_lessons
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
drop policy if exists "Users can delete their own Nano lessons" on public.nano_ai_lessons;
create policy "Users can delete their own Nano lessons" on public.nano_ai_lessons
  for delete to authenticated using ((select auth.uid()) = user_id);
