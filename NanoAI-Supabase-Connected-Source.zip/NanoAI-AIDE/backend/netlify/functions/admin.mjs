import { CORS, json, sb, who } from "../lib/auth.mjs";
export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  const a = await who(req);
  if (!a?.p?.is_admin) return json({ error: "Admin only" }, 403);
  const b = await req.json().catch(() => ({}));
  if (b.action === "list") return json(await (await sb("/rest/v1/profiles?select=id,email,used,used_on,daily_limit,banned,is_admin&order=email")).json());
  if (b.action === "update" && /^[0-9a-f-]{36}$/.test(b.id || "")) {
    const patch = {};
    if (Number.isInteger(b.daily_limit) && b.daily_limit >= 0) patch.daily_limit = b.daily_limit;
    if (typeof b.banned === "boolean") patch.banned = b.banned;
    await sb(`/rest/v1/profiles?id=eq.${b.id}`, { method: "PATCH", body: JSON.stringify(patch) });
    return json({ ok: true });
  }
  return json({ error: "Bad action" }, 400);
};
export const config = { path: "/api/admin" };
