import { CORS, json, env as E, sb, who } from "../lib/auth.mjs";
export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  const b0 = await req.clone().json().catch(() => ({}));
  if (b0.action === "exists") {   // login helper: is there an account for this email? (rate-limited per IP)
    const ip = req.headers.get("x-nf-client-connection-ip") || "x", now = Date.now(), h = (globalThis.__ex ||= new Map()), l = (h.get(ip) || []).filter(t => now - t < 60000);
    if (l.length >= 10) return json({ error: "Too many tries. Wait a minute." }, 429);
    h.set(ip, [...l, now]);
    const em = String(b0.email || "").trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(em)) return json({ error: "Bad email" }, 400);
    const r = await (await sb(`/rest/v1/profiles?email=ilike.${encodeURIComponent(em)}&select=id&limit=1`)).json();
    return json({ exists: Array.isArray(r) && r.length > 0 });
  }
  const a = await who(req);
  if (!a) return json({ error: "Please log in." }, 401);
  const b = await req.json().catch(() => ({}));
  if (b.action === "delete") {   // removes the login; chats and profile cascade-delete
    const r = await fetch(E("SUPABASE_URL") + "/auth/v1/admin/users/" + a.u.id, { method: "DELETE", headers: { apikey: E("SUPABASE_SERVICE_KEY"), Authorization: "Bearer " + E("SUPABASE_SERVICE_KEY") } });
    return json({ ok: r.ok }, r.ok ? 200 : 500);
  }
  return json({ error: "Bad action" }, 400);
};
export const config = { path: "/api/account" };
