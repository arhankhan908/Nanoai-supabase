import { CORS, json, env as E, sb, who } from "../lib/auth.mjs";
const TEXT = ["openai/gpt-oss-120b", "qwen/qwen3.6-27b", "openai/gpt-oss-20b"];   // Groq retired the llama-3.x ids on 2026-08-16
const VISION = ["qwen/qwen3.8-27b", "qwen/qwen3.6-27b"]; // supported multimodal models; fall through only to another vision model
const hits = new Map();
const groq = (body) => fetch("https://api.groq.com/openai/v1/chat/completions", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + E("GROQ_API_KEY") }, body: JSON.stringify(body) });
const textOf = m => typeof m.content === "string" ? m.content : (m.content || []).map(c => c.text || "").join(" ");

// keep newest messages within ~12000 chars (~3000 tokens) so input + reply stays under Groq's 8000 tokens/min
const trim = (ms, cap = 12000) => { let used = 0; const out = []; for (let i = ms.length - 1; i >= 0; i--) { const t = textOf(ms[i]).length; if (out.length && used + t > cap) break; used += t; out.unshift(ms[i]) } if (typeof out[0]?.content === "string" && out[0].content.length > cap) out[0] = { ...out[0], content: out[0].content.slice(0, cap) }; return out };

async function research(q) {   // sub-questions -> web search -> numbered sources
  let qs = [q];
  try { const r = await groq({ model: "openai/gpt-oss-20b", messages: [{ role: "user", content: `Return ONLY a JSON array of 3 short web search queries that together answer: ${q}` }] });
    const a = JSON.parse(((await r.json()).choices[0].message.content.match(/\[[\s\S]*\]/) || ["[]"])[0]); if (a.length) qs = a.slice(0, 3).map(String) } catch {}
  const res = (await Promise.all(qs.map(async x => { try { const r = await fetch("https://api.tavily.com/search", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ api_key: E("TAVILY_API_KEY"), query: x, max_results: 4 }) }); return (await r.json()).results || [] } catch { return [] } }))).flat();
  const seen = new Set(); return res.filter(r => !seen.has(r.url) && seen.add(r.url)).slice(0, 8);
}

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  const a = await who(req);
  if (!a) return json({ error: "Please log in." }, 401);
  const { u, p } = a;
  if (p.banned) return json({ error: "This account is suspended." }, 403);
  if (!u.user_metadata?.age_ok) return json({ error: "Confirm you are 18+ to continue." }, 403);
  const now = Date.now(), h = (hits.get(u.id) || []).filter(t => now - t < 60000);
  if (h.length >= 20) return json({ error: "Slow down: 20 messages per minute max." }, 429);
  hits.set(u.id, [...h, now]);
  const used = p.used_on === new Date().toISOString().slice(0, 10) ? p.used : 0;
  if (!p.is_admin && used >= p.daily_limit) return json({ error: `Daily token limit reached (${p.daily_limit.toLocaleString()}). It resets at midnight UTC.` }, 429);

  let b; try { b = await req.json() } catch { return json({ error: "Bad JSON" }, 400) }
  const { messages = [], mode = "chat", vision = false } = b;
  if (!Array.isArray(messages) || !messages.length || messages.length > 40 || JSON.stringify(messages).length > 4e6) return json({ error: "Bad or too large request." }, 400);

  let sys = "You are Nano Ai, an AI assistant running on Kaiser 1.0 beta. Always introduce yourself as Nano Ai; never claim to be built on, or name, any other company\u2019s model or architecture (never say GPT-4 or OpenAI). Talk casually and naturally, like a smart friend: warm, direct, no stiff corporate phrasing. Be concise. Use markdown.";
  if (mode === "deep") {
    sys += " DEEP MODE: reason through sub-questions, then give a structured report with headings and a conclusion.";
    if (E("TAVILY_API_KEY")) { const src = await research(textOf(messages[messages.length - 1]));
      if (src.length) sys += "\nWEB SOURCES:\n" + src.map((r, i) => `[${i + 1}] ${r.title} (${r.url})\n${(r.content || "").slice(0, 500)}`).join("\n") + "\nCite sources as [n] and end with a Sources list of links." }
  }
  const mult = (mode === "deep" ? 2 : 1) * (vision ? 2 : 1);
  let last = "Unknown error", status = 502;
  for (const model of vision ? VISION : TEXT) {
    const r = await groq({ model, stream: true, stream_options: { include_usage: true }, max_completion_tokens: 1500, ...(model.startsWith("openai/gpt-oss") ? { reasoning_effort: "low" } : {}), messages: [{ role: "system", content: sys }, ...trim(messages)] });
    if (r.ok) {
      let tail = "";
      const ts = new TransformStream({
        transform(ch, c) { c.enqueue(ch); tail = (tail + new TextDecoder().decode(ch)).slice(-2000) },
        async flush() { const m = tail.match(/"total_tokens":\s*(\d+)/g); const n = m ? +m[m.length - 1].split(":")[1] : 0;
          if (n) await sb("/rest/v1/rpc/add_usage", { method: "POST", body: JSON.stringify({ uid: u.id, n: n * mult }) }) } });
      return new Response(r.body.pipeThrough(ts), { headers: { ...CORS, "Content-Type": "text/event-stream", "Cache-Control": "no-cache" } });
    }
    status = r.status; try { last = (await r.json()).error?.message || r.statusText } catch { last = r.statusText }
    if (![400, 404, 429, 503].includes(r.status)) break;
  }
  return json({ error: `${status}: ${last}` }, status);   // message contents are never logged
};
export const config = { path: "/api/chat" };
