# Nano Ai platform: deploy guide
1. Supabase (free): create a project. SQL Editor: run supabase.sql. Auth > URL Configuration: set Site URL to your Netlify link.
2. Paste Project URL and anon key into config.js (SUPABASE_URL, SUPABASE_ANON_KEY). BACKEND_URL is already set.
3. Netlify > Site settings > Environment variables: GROQ_API_KEY, SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_KEY (secret, Supabase > API > service_role), optional TAVILY_API_KEY (free at tavily.com, for web Deep Research).
4. Deploy this whole folder (Netlify CLI `netlify deploy --prod`, or Git). Functions need a real deploy.
5. Open the site, create your account, verify the email, then run in Supabase SQL: update profiles set is_admin = true where email = 'YOU@EMAIL';
6. Google login (optional): Supabase > Auth > Providers > Google, add your Google OAuth client.
Free-tier limits: Groq rate limits are shared by all users; Supabase pauses idle free projects; Supabase's built-in email sender is rate-limited (add SMTP for real launches); the date of birth is self-declared, not verified.

Single-file version: nano-ai-single.html is the same app bundled into one file. To use it as your homepage, rename it to index.html (the netlify folder is still needed).
