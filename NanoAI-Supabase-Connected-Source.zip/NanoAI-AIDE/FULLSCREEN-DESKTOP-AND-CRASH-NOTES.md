# Nano AI — startup diagnostics, full-screen live browser, desktop site

## Changes
- Startup initialization exceptions are caught and shown in a native diagnostic screen rather than silently closing.
- WebView JavaScript console messages are logged under `NanoAI.Web` and `NanoAI.LiveWeb`.
- WebView renderer exits are detected on API 26+ and routed to a diagnostic screen.
- Live WebView now sits in its own frame stage. The fullscreen command and the live toolbar expand it to full height.
- In full screen, tapping the page reveals a native X/exit control at top-right and a Chat button at the bottom. They automatically hide after three seconds. Page clicks and scrolling remain pass-through; AI frame capture pauses while these controls are visible so the overlay does not confuse vision.
- Say `enable desktop site` or `desktop site` to switch to a desktop user agent and reload; `mobile site` turns it off. A Desktop toggle is also on the live dashboard.
- Say `full screen` / `exit full screen`, or use the ⤢ live-toolbar button.
- `go live` continues to open `https://bot.nebulanetwork.club/`.

## How to diagnose any remaining startup crash
This source was not built against an installed Android SDK in this environment and was not run on the target phone. If the app still exits, use AIDE's Run/Build console or Android Logcat and share the first `FATAL EXCEPTION` block. The on-screen startup screen now displays synchronous startup errors. JavaScript errors are logged with source file and line number.

## Limits of validation
Only static syntax, XML, archive, and source consistency checks can be performed here; actual AIDE compilation, install, live PixelCopy frame rate, and full-screen touch behavior must be tested on-device.
