# Nano AI Supabase connection report

## Connected project
- Project ref: `slxwpurkwnnlrjqneyrm`
- `assets/config.js` contains the project URL and its public publishable key.
- No service-role/secret key is bundled.
- Cloud sync target: `public.nano_ai_lessons`.

## Behavior
- The app creates and persists a Supabase anonymous Auth session in WebView storage.
- Lessons are pulled at startup and merged with local lessons; local edits win for duplicate prompts.
- Lessons are upserted by `(user_id, lesson_key)`; removed local lessons are deleted from that user's cloud rows.
- Row Level Security scopes read/write/delete to `auth.uid() = user_id`.
- If network/Auth/cloud sync fails, local lessons remain available.

## Required one-time dashboard step
Enable **Authentication → Sign In / Providers → Anonymous Sign-ins** for this project. The available Supabase connector does not expose an auth-provider configuration action, so this setting has not been changed automatically.

## Validation performed
- `node --check` on every JavaScript file in `assets/`.
- ZIP integrity checked after packaging.
- The live database table and RLS-enabled status were verified through the Supabase connector.
- Not verified: AIDE build, APK install/startup, or a real lesson sync from the user's phone.

## Important limits
This sync stores examples, not model weights. It does not turn the rule-based offline brain into a generative AI and does not itself fix unrelated Android crashes. Anonymous sessions are per-install; clearing app data can lose access to that cloud identity unless account linking is added later.
