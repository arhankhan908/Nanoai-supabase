# Nano AI Offline Brain Patch — Test Report

## Behavior changes
- Local provider is now named **Offline Brain** and defaults to `offline://`.
- Local provider selection no longer calls `GET /v1/models` or `POST /v1/chat/completions`.
- General chat uses the bundled local example matcher/rules when `nano_prov=local`.
- Live-agent `window.aiOnce` returns locally generated action-plan JSON from the current visible DOM/text, without a model-server request.
- URL reading via the remote Jina reader is skipped in offline provider mode.
- Removed the remote Supabase SDK script tag from the default offline app HTML; local accounts were already the default when Supabase placeholders are present.
- Added local teach/forget examples:
  - `teach nano: when I say "hello", reply "Hey!"`
  - `teach nano: "hello" => "Hey!"`
  - `forget nano: hello`
  - `show nano training`
- Custom examples persist in WebView local storage on this device (up to 500).

## Checks actually run
- `node --check` on `assets/app.js`, `assets/live.js`, `assets/commands.js`, `assets/auth.js`, and `assets/config.js`: passed.
- `node --check` on all 6 inline JavaScript blocks in `nano-ai-single.html`: passed.
- Offline brain Node smoke tests for greeting, teaching syntax, click planning by visible element label/index, typing into the matching username field, custom lesson recall, and forgetting a lesson: passed.
- Android manifest XML parse: passed.
- ZIP integrity: checked when packaging.
- External `<script src=https://...>` tags in `assets/index.html` and `nano-ai-single.html`: none.

## Important limitations
This is an on-device rule/example-matching brain, not a neural generative LLM. General free-form language generation and screenshot-based vision are not available without adding a true on-device inference runtime and model weights. The actual website opened in Go Live still needs internet because it is a website. No Android SDK/device was available here, so no APK build, device install, memory soak, or real WebView test was performed.
