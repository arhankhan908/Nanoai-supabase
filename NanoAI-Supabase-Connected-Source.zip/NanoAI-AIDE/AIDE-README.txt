NANO AI: AIDE PROJECT
1. Copy this folder to your phone. AIDE > Open project > pick the folder with AndroidManifest.xml. Tap Run.
2. The app defaults to On-device Offline Brain: no AI API key or model server is needed. Teach local examples using `teach nano: when I say "hello", reply "Hey!"`. The optional `training/` folder contains an experimental PC fine-tuning/server pipeline, not required for normal offline mode.
   It stores examples in this device’s local storage. Use `forget nano: hello` to remove a lesson and `show nano training` to see the number of custom lessons. This is example-based offline behavior, not a full generative LLM or image-vision model.
3. Icon: replace res/drawable/ic_launcher.png with your rose photo (same file name).
OPTIONAL online accounts: put real SUPABASE_URL + SUPABASE_ANON_KEY in assets/config.js and deploy backend/ (see backend/README.md).


LIVE BROWSER VISION (this build)
- The real live WebView stays visible. On Android 8.0/API 26 or newer, PixelCopy captures the visible WebView asynchronously and keeps only the newest JPEG frame (maximum width 720 px, JPEG quality 64).
- Capture is capped at 15 FPS by default. Say `capture fps 5` (1–15) to set the capture limit. Actual capture FPS is measured on-device; it is not guaranteed to reach the configured limit. Busy/stale frames are dropped, not queued.
- The model receives one fresh screenshot plus accessible DOM/text per agent reasoning step; it does NOT send every 15-FPS frame to the AI. This keeps model request rate and cost separate from capture rate.
- Groq vision selection checks the account's `/models` list for supported Qwen vision models (or another listed supported vision model). Mistral vision selection also checks its `/models` list. If no image model can be verified, the agent reports an error rather than silently using a text-only model. Official compatibility references: https://console.groq.com/docs/vision and https://docs.mistral.ai/studio/conversations/vision
- The provider receives screenshots in each vision request. Screenshots can contain personal page content. Avoid opening private pages unless you are comfortable sending the visible page to the selected AI provider. API keys are not written to logs by this feature.
- Frame capture reports an explicit unsupported status below API 26 because Window PixelCopy is unavailable there. It pauses on navigation/background/close and cancels stale cached frames.
- The agent stops if it detects CAPTCHA/anti-bot, MFA/passkey, or other verification challenges. Complete those manually in the visible browser; Nano AI will not attempt to solve or bypass them.
- Click attempts show a cyan target marker briefly and are checked against a subsequent DOM/page-state snapshot. If no change can be confirmed, the app reports the click as unverified instead of claiming success.
- Pricing is provider/model-dependent and can change. Image input is billed according to the selected model's current image/token pricing. Because only reasoning-step frames are sent (not all capture frames), capture FPS itself does not multiply AI calls. See the provider's current pricing before use; no fixed cost estimate is hard-coded.


GROQ API KEY SETUP (IMPORTANT)
- The app supports multiple Groq keys separated by commas.
- Prefer entering keys in Account > AI key; for a private local build, set GROQ_API_KEY in assets/config.js.
- nano-ai-single.html contains a bundled copy of the config; keep it in sync if using the single-file build.
- Never publish/share source or APKs containing real API keys. Client-side keys can be extracted.
- Any key pasted into a public chat or shared source should be revoked and replaced.


API KEY FLOATING PANEL / CLOUD VAULT
- In chat, type "give key", "I want to give key", "add Groq key", or "add Mistral key". A floating panel opens; the phrase is not sent to the AI.
- Save key stores the provider key on this device so Nano Ai can use it. For cloud backup, configure Supabase as described above, re-run the updated backend/supabase.sql, and enter a vault passphrase (8+ characters) in the panel.
- Cloud backups are encrypted in the browser with PBKDF2 + AES-GCM before being uploaded. The cloud stores ciphertext only. The vault passphrase is not recoverable; do not forget it.
- Keys still saved on the same device are used from that device's local provider settings. Use Restore from cloud on a new device and enter the vault passphrase. If Supabase isn't configured, the app explicitly says the key is device-only.
- Rate-limit cooldowns now honor Groq's retry-after and x-ratelimit-reset-* headers when supplied, instead of assuming exactly 60 seconds.


Local AI mode: see LOCAL-AI-NO-API-KEY.md. Configure Local AI (no API key) in Account → AI key. A compatible local model server is required.


NANO LOCAL 0.1 TRAINING PACK
- `training/nano_training.jsonl` contains 86 training examples plus 10 fixed validation examples (96 total).
- `training/train.py` fine-tunes Qwen2.5-0.5B-Instruct using LoRA; it does not train a foundation model from scratch.
- `training/server.py` exposes `/v1/models` and streaming/non-streaming `/v1/chat/completions` for this adapter.
- Follow `training/README.md`. The model is text-only; use a vision-language model for screenshot reasoning.
