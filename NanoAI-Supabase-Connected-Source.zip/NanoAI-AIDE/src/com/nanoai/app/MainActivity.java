package com.nanoai.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import android.view.PixelCopy;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private WebView web;                  // chat app
    private WebView live;                 // the actual live browser shown above chat
    private LinearLayout root;
    private FrameLayout liveStage;
    private TextView liveExitButton, liveChatButton;
    private boolean liveFullscreen = false;
    private boolean desktopSiteEnabled = false;
    private String liveCurrentUrl = "about:blank";
    private int partialLiveHeight = 0;
    private final Handler overlayHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideFullscreenControls = new Runnable() { public void run() { if (liveFullscreen && liveExitButton != null) { liveExitButton.setVisibility(View.GONE); if (liveChatButton != null) liveChatButton.setVisibility(View.GONE); } } };
    private ValueCallback<Uri[]> pick;
    private static final int PICK = 7;

    // Latest-only frame pipeline: one PixelCopy, one encoder, one cached JPEG.
    // A frame is never queued for every tick; overloaded ticks are dropped.
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private HandlerThread frameThread;
    private Handler frameHandler;
    private final ExecutorService encodeExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean copyInFlight = new AtomicBoolean(false);
    private final AtomicBoolean encodeInFlight = new AtomicBoolean(false);
    private volatile boolean captureRunning = false;
    private volatile byte[] latestJpeg;
    private volatile long latestFrameAtMs;
    private volatile String captureState = "idle";
    private volatile int pageEpoch = 0;
    private int requestedFps = 15;
    private int effectiveFps = 15;
    private int measuredCaptureFps = 0;
    private int successfulInWindow = 0;
    private int droppedInWindow = 0;
    private int droppedTotal = 0;
    private int stableWindows = 0;
    private long measureWindowAt = SystemClock.elapsedRealtime();

    private final Runnable captureTick = new Runnable() {
        @Override public void run() { captureOneTick(); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            initializeApp(b);
        } catch (Throwable error) {
            android.util.Log.e("NanoAI", "Startup failed", error);
            showStartupError(error);
        }
    }

    private void initializeApp(Bundle b) {
        web = new WebView(this);
        live = new WebView(this);
        liveStage = new FrameLayout(this);
        liveStage.setVisibility(View.GONE);
        liveStage.setBackgroundColor(Color.BLACK);
        liveStage.addView(live, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // The controls are native overlays above the real WebView, not part of the page DOM.
        liveExitButton = makeOverlayButton("×");
        liveExitButton.setTextSize(27f);
        liveChatButton = makeOverlayButton("Chat");
        liveChatButton.setTextSize(15f);
        FrameLayout.LayoutParams exitLp = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP | Gravity.RIGHT);
        exitLp.setMargins(0, dp(12), dp(12), 0);
        liveStage.addView(liveExitButton, exitLp);
        FrameLayout.LayoutParams chatLp = new FrameLayout.LayoutParams(dp(112), dp(44), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        chatLp.setMargins(0, 0, 0, dp(18));
        liveStage.addView(liveChatButton, chatLp);
        liveExitButton.setVisibility(View.GONE);
        liveChatButton.setVisibility(View.GONE);
        liveExitButton.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { exitLiveFullscreen(true); } });
        liveChatButton.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { exitLiveFullscreen(true); } });
        live.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (liveFullscreen && event.getAction() == MotionEvent.ACTION_UP) showFullscreenControls();
                return false; // preserve regular website clicks and scrolling
            }
        });

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(liveStage, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 0f));
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(true);

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return route(r.getUrl()); }
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
                android.util.Log.e("NanoAI", "App WebView renderer gone; crashed=" + detail.didCrash());
                showStartupError(new RuntimeException("The app's browser engine stopped (crashed=" + detail.didCrash() + "). Reopen Nano AI; if it repeats, send the AIDE/Logcat error."));
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                android.util.Log.d("NanoAI.Web", message.message() + " (" + message.sourceId() + ":" + message.lineNumber() + ")");
                return true;
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (pick != null) pick.onReceiveValue(null);
                pick = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String[] t = p.getAcceptTypes();
                i.setType(t != null && t.length > 0 && t[0] != null && t[0].startsWith("image") ? "image/*" : "*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(Intent.createChooser(i, "Attach"), PICK); }
                catch (ActivityNotFoundException e) { pick = null; return false; }
                return true;
            }
        });

        WebSettings ls = live.getSettings();
        ls.setJavaScriptEnabled(true);
        ls.setDomStorageEnabled(true);
        ls.setAllowFileAccess(false);
        ls.setJavaScriptCanOpenWindowsAutomatically(true);
        ls.setSupportMultipleWindows(false);
        applyDesktopSettings();
        live.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                return !("http".equals(sc) || "https".equals(sc));
            }
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
                liveCurrentUrl = url == null ? "about:blank" : url;
                pauseForNavigation();
            }
            @Override public void onPageFinished(WebView v, String url) {
                liveCurrentUrl = url == null ? liveCurrentUrl : url;
                String u = liveCurrentUrl.replace("\\", "").replace("'", "");
                if (web != null) web.evaluateJavascript("window.Live&&Live._loaded('" + u + "')", null);
                if (liveStage.getVisibility() == View.VISIBLE) startFrameCapture();
            }
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
                android.util.Log.e("NanoAI", "Live WebView renderer gone; crashed=" + detail.didCrash());
                stopFrameCapture("webview-renderer-crashed");
                showStartupError(new RuntimeException("The live browser engine stopped (crashed=" + detail.didCrash() + "). Reopen Nano AI; if it repeats, send the AIDE/Logcat error."));
                return true;
            }
        });
        live.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                android.util.Log.d("NanoAI.LiveWeb", message.message() + " (" + message.sourceId() + ":" + message.lineNumber() + ")");
                return true;
            }
        });
        web.addJavascriptInterface(new LiveBridge(), "NanoLive");

        if (Build.VERSION.SDK_INT >= 26) {
            frameThread = new HandlerThread("NanoLiveFrameCopy");
            frameThread.start();
            frameHandler = new Handler(frameThread.getLooper());
        }

        if (b == null) web.loadUrl("file:///android_asset/index.html");
        else {
            try {
                if (web.restoreState(b) == null) web.loadUrl("file:///android_asset/index.html");
            } catch (Throwable restoreError) {
                android.util.Log.w("NanoAI", "WebView restore failed; loading local app", restoreError);
                web.loadUrl("file:///android_asset/index.html");
            }
        }
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private TextView makeOverlayButton(String label) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(220, 18, 19, 30));
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.argb(150, 140, 125, 255));
        t.setBackground(bg);
        t.setElevation(dp(8));
        return t;
    }

    private void showFullscreenControls() {
        if (!liveFullscreen || liveExitButton == null) return;
        overlayHandler.removeCallbacks(hideFullscreenControls);
        liveExitButton.setVisibility(View.VISIBLE);
        liveChatButton.setVisibility(View.VISIBLE);
        overlayHandler.postDelayed(hideFullscreenControls, 3000);
    }

    private void enterLiveFullscreen() {
        liveFullscreen = true;
        web.setVisibility(View.GONE);
        liveStage.setVisibility(View.VISIBLE);
        liveStage.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 0f));
        showFullscreenControls();
        live.post(new Runnable() { @Override public void run() { startFrameCapture(); } });
    }

    private void exitLiveFullscreen(boolean revealControls) {
        overlayHandler.removeCallbacks(hideFullscreenControls);
        liveFullscreen = false;
        if (liveExitButton != null) liveExitButton.setVisibility(View.GONE);
        if (liveChatButton != null) liveChatButton.setVisibility(View.GONE);
        web.setVisibility(View.VISIBLE);
        int h = partialLiveHeight > 0 ? partialLiveHeight : Math.round(getResources().getDisplayMetrics().heightPixels * 0.45f);
        liveStage.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h, 0f));
        liveStage.setVisibility(View.VISIBLE);
        if (revealControls && web != null) web.evaluateJavascript("(function(){var e=document.getElementById('in');if(e){e.scrollIntoView({block:'end'});}})()", null);
        startFrameCapture();
    }

    private void applyDesktopSettings() {
        if (live == null) return;
        WebSettings s = live.getSettings();
        s.setUseWideViewPort(desktopSiteEnabled);
        s.setLoadWithOverviewMode(desktopSiteEnabled);
        if (desktopSiteEnabled) {
            s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
        } else {
            s.setUserAgentString(WebSettings.getDefaultUserAgent(this));
        }
    }

    private void showStartupError(Throwable error) {
        try {
            TextView message = new TextView(this);
            message.setTextColor(Color.WHITE);
            message.setTextSize(16f);
            message.setPadding(dp(24), dp(28), dp(24), dp(28));
            String detail = error == null ? "Unknown startup error" : error.getClass().getSimpleName() + ": " + String.valueOf(error.getMessage());
            message.setText("Nano AI could not start.\n\n" + detail + "\n\nOpen AIDE Build/Run output or Android logcat for the full error. Please send that error so it can be fixed accurately.");
            message.setBackgroundColor(Color.rgb(10, 11, 18));
            setContentView(message);
        } catch (Throwable ignored) { finish(); }
    }

    private class LiveBridge {
        @JavascriptInterface public void show(final float frac) {
            runOnUiThread(new Runnable() { public void run() {
                float bounded = Math.max(0.2f, Math.min(1.0f, frac));
                if (bounded < 0.85f) partialLiveHeight = (int) (getResources().getDisplayMetrics().heightPixels * bounded);
                liveStage.setVisibility(View.VISIBLE);
                if (bounded >= 0.85f) enterLiveFullscreen();
                else {
                    if (liveFullscreen) exitLiveFullscreen(false);
                    web.setVisibility(View.VISIBLE);
                    liveStage.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, partialLiveHeight, 0f));
                    live.post(new Runnable() { public void run() { startFrameCapture(); } });
                }
            }});
        }
        @JavascriptInterface public void open(final String url) {
            runOnUiThread(new Runnable() { public void run() {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    liveCurrentUrl = url;
                    applyDesktopSettings();
                    live.loadUrl(url);
                }
            }});
        }
        @JavascriptInterface public void desktop(final boolean enabled) {
            runOnUiThread(new Runnable() { public void run() {
                desktopSiteEnabled = enabled;
                applyDesktopSettings();
                if (liveCurrentUrl != null && liveCurrentUrl.startsWith("http")) live.loadUrl(liveCurrentUrl);
                if (web != null) web.evaluateJavascript("window.Live&&Live._desktopChanged(" + enabled + ")", null);
            }});
        }
        @JavascriptInterface public void blank() {
            runOnUiThread(new Runnable() { public void run() {
                live.loadDataWithBaseURL(null, "<html><body style='margin:0;background:#07070B;color:#8A90A6;font:16px sans-serif;display:flex;align-items:center;justify-content:center;height:100vh'>LIVE</body></html>", "text/html", "utf-8", null);
            }});
        }
        @JavascriptInterface public void close() {
            runOnUiThread(new Runnable() { public void run() {
                stopFrameCapture("closed");
                overlayHandler.removeCallbacks(hideFullscreenControls);
                liveFullscreen = false;
                liveStage.setVisibility(View.GONE);
                web.setVisibility(View.VISIBLE);
                live.loadUrl("about:blank");
            }});
        }
        @JavascriptInterface public void nav(final String what) {
            runOnUiThread(new Runnable() { public void run() {
                if ("back".equals(what) && live.canGoBack()) live.goBack();
                else if ("reload".equals(what)) live.reload();
            }});
        }
        // Run JS inside the live page; results return to the chat page as Live._done(id, result).
        @JavascriptInterface public void run(final String id, final String js) {
            runOnUiThread(new Runnable() { public void run() {
                live.evaluateJavascript(js, new ValueCallback<String>() {
                    public void onReceiveValue(String v) {
                        String safe = id == null ? "0" : id.replaceAll("[^0-9]", "");
                        web.evaluateJavascript("window.Live&&Live._done(" + (safe.length() == 0 ? "0" : safe) + "," + (v == null ? "null" : v) + ")", null);
                    }
                });
            }});
        }
        // Return a fresh cached frame immediately. No waiting queue and no capture work here.
        @JavascriptInterface public void frame(final String id) {
            String safe = id == null ? "0" : id.replaceAll("[^0-9]", "");
            byte[] jpeg = latestJpeg;
            long ts = latestFrameAtMs;
            long age = ts == 0 ? Long.MAX_VALUE : Math.max(0, System.currentTimeMillis() - ts);
            String data = null;
            if (jpeg != null && age <= 1400 && captureRunning) {
                data = "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP);
            }
            final String dataJson = data == null ? "null" : JSONObject.quote(data);
            final long frameTs = data == null ? 0 : ts;
            final String safeId = safe.length() == 0 ? "0" : safe;
            runOnUiThread(new Runnable() { public void run() {
                if (web != null) web.evaluateJavascript("window.Live&&Live._frameReceived(" + safeId + "," + dataJson + "," + frameTs + ")", null);
            }});
        }
        @JavascriptInterface public void setCaptureFps(final int fps) {
            runOnUiThread(new Runnable() { public void run() {
                requestedFps = Math.max(1, Math.min(15, fps));
                effectiveFps = Math.min(effectiveFps, requestedFps);
                notifyTelemetry();
            }});
        }
    }

    private void startFrameCapture() {
        if (live == null || liveStage == null || liveStage.getVisibility() != View.VISIBLE) return;
        if (Build.VERSION.SDK_INT < 26 || frameHandler == null) {
            captureRunning = false;
            captureState = "unsupported: Android 8+ required";
            latestJpeg = null;
            latestFrameAtMs = 0;
            notifyTelemetry();
            return;
        }
        if (captureRunning) return;
        captureRunning = true;
        captureState = "capturing";
        latestJpeg = null;
        latestFrameAtMs = 0;
        effectiveFps = Math.max(1, Math.min(requestedFps, effectiveFps));
        measureWindowAt = SystemClock.elapsedRealtime();
        successfulInWindow = 0;
        droppedInWindow = 0;
        mainHandler.removeCallbacks(captureTick);
        mainHandler.post(captureTick);
        notifyTelemetry();
    }

    private void pauseForNavigation() {
        pageEpoch++;
        captureRunning = false;
        captureState = "navigating";
        latestJpeg = null;
        latestFrameAtMs = 0;
        mainHandler.removeCallbacks(captureTick);
        notifyTelemetry();
    }

    private void stopFrameCapture(String state) {
        pageEpoch++;
        captureRunning = false;
        captureState = state;
        latestJpeg = null;
        latestFrameAtMs = 0;
        mainHandler.removeCallbacks(captureTick);
        notifyTelemetry();
    }

    private void captureOneTick() {
        if (!captureRunning) return;
        if (Build.VERSION.SDK_INT < 26 || frameHandler == null) {
            captureState = "unsupported: Android 8+ required";
            captureRunning = false;
            notifyTelemetry();
            return;
        }
        if (liveStage == null || liveStage.getVisibility() != View.VISIBLE || live.getWidth() < 2 || live.getHeight() < 2 || (liveFullscreen && liveExitButton != null && liveExitButton.getVisibility() == View.VISIBLE)) {
            countDrop();
            scheduleNextTick();
            return;
        }
        if (copyInFlight.get() || encodeInFlight.get()) {
            countDrop();
            scheduleNextTick();
            updateMeasurement();
            return;
        }
        if (!copyInFlight.compareAndSet(false, true)) {
            countDrop();
            scheduleNextTick();
            return;
        }

        final int epoch = pageEpoch;
        int[] xy = new int[2];
        live.getLocationInWindow(xy);
        final Rect src = new Rect(xy[0], xy[1], xy[0] + live.getWidth(), xy[1] + live.getHeight());
        int outW = Math.min(live.getWidth(), 720);
        int outH = Math.max(1, Math.round(live.getHeight() * (outW / (float) live.getWidth())));
        final Bitmap bitmap;
        try {
            bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError oom) {
            copyInFlight.set(false);
            countDrop();
            captureState = "memory-pressure";
            scheduleNextTick();
            updateMeasurement();
            return;
        }

        try {
            PixelCopy.request(getWindow(), src, bitmap, new PixelCopy.OnPixelCopyFinishedListener() {
                @Override public void onPixelCopyFinished(final int result) {
                    mainHandler.post(new Runnable() { public void run() {
                        copyInFlight.set(false);
                        if (!captureRunning || epoch != pageEpoch) {
                            if (!bitmap.isRecycled()) bitmap.recycle();
                            return;
                        }
                        if (result != PixelCopy.SUCCESS) {
                            if (!bitmap.isRecycled()) bitmap.recycle();
                            countDrop();
                            captureState = "capture-error:" + result;
                            updateMeasurement();
                            return;
                        }
                        if (!encodeInFlight.compareAndSet(false, true)) {
                            if (!bitmap.isRecycled()) bitmap.recycle();
                            countDrop();
                            updateMeasurement();
                            return;
                        }
                        final long capturedAt = System.currentTimeMillis();
                        try {
                            encodeExecutor.execute(new Runnable() { public void run() {
                                try {
                                    ByteArrayOutputStream out = new ByteArrayOutputStream(48 * 1024);
                                    boolean ok = bitmap.compress(Bitmap.CompressFormat.JPEG, 64, out);
                                    final byte[] bytes = ok ? out.toByteArray() : null;
                                    if (bytes != null && bytes.length > 0 && captureRunning && epoch == pageEpoch) {
                                        mainHandler.post(new Runnable() { public void run() {
                                            // Cache writes happen on the UI thread so navigation invalidation
                                            // cannot race an old encoder result back into the latest-frame slot.
                                            if (captureRunning && epoch == pageEpoch) {
                                                latestJpeg = bytes;
                                                latestFrameAtMs = capturedAt;
                                                successfulInWindow++;
                                                captureState = "capturing";
                                                updateMeasurement();
                                            }
                                        }});
                                    }
                                } catch (Throwable ignored) {
                                    mainHandler.post(new Runnable() { public void run() { countDrop(); updateMeasurement(); }});
                                } finally {
                                    if (!bitmap.isRecycled()) bitmap.recycle();
                                    encodeInFlight.set(false);
                                }
                            }});
                        } catch (RuntimeException ex) {
                            encodeInFlight.set(false);
                            if (!bitmap.isRecycled()) bitmap.recycle();
                            countDrop();
                            updateMeasurement();
                        }
                    }});
                }
            }, frameHandler);
        } catch (RuntimeException ex) {
            copyInFlight.set(false);
            if (!bitmap.isRecycled()) bitmap.recycle();
            countDrop();
            captureState = "capture-error";
        }
        scheduleNextTick();
        updateMeasurement();
    }

    private void scheduleNextTick() {
        if (!captureRunning) return;
        int fps = Math.max(1, Math.min(requestedFps, effectiveFps));
        mainHandler.postDelayed(captureTick, Math.max(66, 1000 / fps));
    }

    private void countDrop() {
        droppedTotal++;
        droppedInWindow++;
    }

    private void updateMeasurement() {
        long now = SystemClock.elapsedRealtime();
        long elapsed = now - measureWindowAt;
        if (elapsed < 1000) return;
        measuredCaptureFps = (int) Math.round(successfulInWindow * 1000.0 / Math.max(1, elapsed));
        if (droppedInWindow > Math.max(1, successfulInWindow / 2) && effectiveFps > 2) {
            effectiveFps = Math.max(2, effectiveFps - 2);
            stableWindows = 0;
        } else if (droppedInWindow <= 1 && effectiveFps < requestedFps) {
            stableWindows++;
            if (stableWindows >= 2) { effectiveFps++; stableWindows = 0; }
        } else {
            stableWindows = 0;
        }
        successfulInWindow = 0;
        droppedInWindow = 0;
        measureWindowAt = now;
        notifyTelemetry();
    }

    private void notifyTelemetry() {
        if (web == null) return;
        final String state = captureState == null ? "idle" : captureState;
        final int measured = measuredCaptureFps;
        final int limit = requestedFps;
        final int effective = effectiveFps;
        final int dropped = droppedTotal;
        final long ts = latestFrameAtMs;
        Runnable r = new Runnable() { public void run() {
            if (web == null) return;
            String js = "window.Live&&Live._nativeTelemetry(" + measured + "," + limit + "," + effective + "," + dropped + "," + ts + "," + JSONObject.quote(state) + ")";
            web.evaluateJavascript(js, null);
        }};
        if (Looper.myLooper() == Looper.getMainLooper()) r.run(); else mainHandler.post(r);
    }

    // Keep links inside the app only for local pages; external/app links retain existing behavior.
    private boolean route(Uri u) {
        String sc = u.getScheme() == null ? "" : u.getScheme();
        if (sc.equals("file")) return false;
        try {
            if (sc.equals("intent")) startActivity(Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME));
            else startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception ignored) { }
        return true;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        if (req != PICK || pick == null) return;
        Uri[] out = null;
        if (res == RESULT_OK && d != null) {
            if (d.getClipData() != null) {
                int n = d.getClipData().getItemCount();
                out = new Uri[n];
                for (int i = 0; i < n; i++) out[i] = d.getClipData().getItemAt(i).getUri();
            } else if (d.getData() != null) out = new Uri[]{ d.getData() };
        }
        pick.onReceiveValue(out);
        pick = null;
    }

    @Override protected void onPause() {
        super.onPause();
        if (live != null && liveStage != null && liveStage.getVisibility() == View.VISIBLE) {
            stopFrameCapture("paused");
            if (web != null) web.evaluateJavascript("window.Live&&Live._nativePaused()", null);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (live != null && liveStage != null && liveStage.getVisibility() == View.VISIBLE) startFrameCapture();
    }

    @Override protected void onSaveInstanceState(Bundle b) { super.onSaveInstanceState(b); if (web != null) web.saveState(b); }

    @Override protected void onDestroy() {
        stopFrameCapture("destroyed");
        overlayHandler.removeCallbacksAndMessages(null);
        mainHandler.removeCallbacksAndMessages(null);
        if (frameThread != null) { frameThread.quitSafely(); frameThread = null; }
        encodeExecutor.shutdownNow();
        if (live != null) live.destroy();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (liveFullscreen) {
            exitLiveFullscreen(true);
        } else if (liveStage != null && liveStage.getVisibility() == View.VISIBLE) {
            stopFrameCapture("closed");
            overlayHandler.removeCallbacks(hideFullscreenControls);
            liveFullscreen = false;
            liveStage.setVisibility(View.GONE);
            web.setVisibility(View.VISIBLE);
            live.loadUrl("about:blank");
            web.evaluateJavascript("window.Live&&Live._closed()", null);
        } else if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
