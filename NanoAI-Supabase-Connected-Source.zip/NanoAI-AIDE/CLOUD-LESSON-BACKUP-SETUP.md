# Nano cloud lesson backup (optional)

This adds a cloud backup for examples taught with `teach nano: ...`. Nano still uses its lightweight example matcher; this is not neural-network training and does not move the Android UI or browser engine into the cloud. Cloud backup by itself will not fix an Android/WebView crash.

## Set up Supabase

1. This source is already configured for your connected Supabase project (`slxwpurkwnnlrjqneyrm`) using its public publishable key. No service-role key is included.
2. The `public.nano_ai_lessons` table has been created and Row Level Security is enabled.
3. In **Authentication → Sign In / Providers** (wording may vary), enable **Anonymous Sign-ins**. The app uses this separate anonymous session for per-install lesson backup.
4. Rebuild/reinstall the app with AIDE and open it while online. Existing local lessons are merged with cloud lessons; new lessons and `forget nano:` changes sync in the background. If cloud sync fails, local saving still works.

## Important limits

- The anonymous cloud identity is stored in this app's WebView storage. Clearing app data or reinstalling may lose access to that anonymous cloud identity and its lessons. This is per-install backup, not yet a cross-device account.
- Keep Supabase Row Level Security enabled. The table policies allow each authenticated identity to access only its own lesson rows.
- The Supabase JavaScript SDK is loaded from jsDelivr because this build is configured for cloud sync. Offline lesson storage still works if the SDK or network is unavailable.
- Cloud storage saves teaching examples, not model weights. Nano's offline brain remains rule/example-based and won't become a full generative model just by storing lessons online.
- No Android SDK/device was available for a real APK startup test. This patch was checked with JavaScript syntax and project/ZIP checks only.

## If Nano still crashes

This cloud backup is separate from the crash. Send the first `FATAL EXCEPTION` / `NanoAI` error from AIDE Logcat (or a screenshot of the crash message). The trace is needed to identify whether the problem is Activity startup, WebView renderer, Android compatibility, or page JavaScript.
