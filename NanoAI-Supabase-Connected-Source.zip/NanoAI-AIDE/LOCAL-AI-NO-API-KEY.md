# Nano AI — On-device Offline Brain

Nano AI now defaults to **Offline Brain**. For chat replies and common live-browser actions, the app does not call Groq, Mistral, a remote chat backend, `127.0.0.1`, or a PC model server. There is no URL or CORS setup in this mode.

## What this offline mode can do

- Match against bundled starter examples.
- Save up to 500 custom phrase → answer lessons in the app's local storage.
- Use built-in rules to plan common browser actions from accessible DOM labels, such as clicks, typing into labelled inputs, opening URLs, scrolling, and going back.
- Keep user-taught examples on this device.

Teach Nano an answer by sending:

`teach nano: when I say "hello", reply "Hey!"`

You can also use:

`teach nano: "hello" => "Hey!"`

Remove a lesson with `forget nano: hello`. List the count with `show nano training`.

## Honest limitation

This is an offline rule + example-matching brain, **not a full generative language model**. It does not have neural text generation or screenshot vision. An actual on-device LLM needs an inference runtime and compatible model weights bundled/imported onto Android; a vision model needs image-capable weights too. The old `training/` folder remains as an optional PC experimentation pipeline, but its model server is not used by the app's default offline mode.

The Go Live browser still loads the website you request, so that website itself needs internet. AI chat reasoning in Offline Brain mode does not use the network.

## Checks

JavaScript syntax checks and offline planner/lesson smoke tests can be run with Node on the project source. APK build and real-device behavior must still be tested in AIDE on the target phone.
