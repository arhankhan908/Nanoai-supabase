# Go Live and API Key Merge Fix

- `go live` now opens `https://bot.nebulanetwork.club/` in the live browser.
- The AI-assisted `go live ...` entry path opens the same URL first.
- Saving API keys appends them to existing keys for the selected provider and removes duplicates while preserving order.
- When cloud vault is configured and a passphrase is provided, existing encrypted cloud keys are decrypted and merged before the updated list is encrypted and saved. If that merge fails, the cloud value is not overwritten.

Validation: run JavaScript syntax checks and ZIP integrity checks. Android/device runtime tests are still required.
