# Nano AI — Click and Live Dashboard Update

## Changes
- Expanded click-target discovery to visible buttons, links, menu items, tabs, options, labels, custom `onclick` elements, and elements with `tabindex` or test IDs.
- Matches exact visible labels first, then partial labels and word matches; reports disabled or missing targets instead of claiming success.
- Enumerates open shadow roots and accessible same-origin iframes for the page snapshot, index clicks, and indexed text entry.
- Adds a visible click marker at the target's page coordinates and retains post-click state/frame verification.
- Refines the live telemetry bar styling for clearer status and metrics on mobile.
- Synchronizes `assets/live.js` into `nano-ai-single.html` so the two delivery paths use the same implementation.

## Boundaries / known limits
- Cross-origin iframe DOM is not accessible to page JavaScript. Native coordinate input would need a separately implemented and device-tested Android bridge; this patch does not pretend to click inside inaccessible frames.
- The app/dashboard WebView and the separate live-browser WebView are different surfaces. A page click can only target the live browser's page, not controls in the Nano AI app UI or another WebView.
- CAPTCHA, MFA, identity checks, and other security challenges remain manual.
- Composio is for authorized external app integrations; it does not directly control this Android app's embedded WebView. No external app connection was needed for this local source patch.

## Verification
- `node --check` passed for the live-browser source and bundled inline JavaScript blocks.
- ZIP integrity checked after packaging.
- Android/AIDE build and real-device interaction tests were not available in this environment; no FPS or runtime success is claimed.
