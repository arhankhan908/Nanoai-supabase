#!/usr/bin/env python3
"""Fine-tune a small local Nano assistant with LoRA (no API key required).

This downloads the public base checkpoint once, trains on nano_training.jsonl,
then saves a lightweight adapter. It does not train a foundation model from scratch.
"""
import argparse
import json
import random
from pathlib import Path
from typing import Dict, List

import torch
from torch.utils.data import Dataset
from transformers import (AutoModelForCausalLM, AutoTokenizer, Trainer,
                          TrainingArguments, set_seed)
from peft import LoraConfig, get_peft_model, TaskType

HERE = Path(__file__).resolve().parent
DEFAULT_DATA = HERE / "nano_training.jsonl"
DEFAULT_VALIDATION = HERE / "nano_validation.jsonl"
DEFAULT_BASE = "Qwen/Qwen2.5-0.5B-Instruct"

class ChatDataset(Dataset):
    def __init__(self, rows: List[dict], tokenizer, max_length: int):
        self.items = []
        self.tokenizer = tokenizer
        for row in rows:
            messages = row.get("messages")
            if not isinstance(messages, list) or len(messages) < 2 or messages[-1].get("role") != "assistant":
                continue
            prompt_messages = messages[:-1]
            prompt_ids = tokenizer.apply_chat_template(
                prompt_messages, tokenize=True, add_generation_prompt=True
            )
            full_ids = tokenizer.apply_chat_template(
                messages, tokenize=True, add_generation_prompt=False
            )
            # Mask prompt tokens so the loss teaches the assistant response, not user text.
            common = 0
            for a, b in zip(prompt_ids, full_ids):
                if a != b:
                    break
                common += 1
            ids = list(full_ids[:max_length])
            prefix_len = min(common, len(ids))
            labels = [-100] * prefix_len + ids[prefix_len:]
            if not ids or not any(x != -100 for x in labels):
                continue
            self.items.append({"input_ids": ids, "labels": labels})
        if not self.items:
            raise ValueError("No usable training samples found. Check nano_training.jsonl format.")

    def __len__(self):
        return len(self.items)

    def __getitem__(self, index):
        return self.items[index]

class PadCollator:
    def __init__(self, pad_id: int):
        self.pad_id = pad_id

    def __call__(self, rows):
        size = max(len(row["input_ids"]) for row in rows)
        input_ids, attention_mask, labels = [], [], []
        for row in rows:
            n = len(row["input_ids"])
            pad = size - n
            input_ids.append(row["input_ids"] + [self.pad_id] * pad)
            attention_mask.append([1] * n + [0] * pad)
            labels.append(row["labels"] + [-100] * pad)
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }

def main():
    p = argparse.ArgumentParser(description="Fine-tune Nano Ai (LoRA, no API key)")
    p.add_argument("--data", default=str(DEFAULT_DATA))
    p.add_argument("--validation-data", default=str(DEFAULT_VALIDATION), help="Fixed validation JSONL. Pass an empty string to make a seeded 90/10 split from --data.")
    p.add_argument("--base-model", default=DEFAULT_BASE)
    p.add_argument("--output-dir", default="output/nano-local-0.1")
    p.add_argument("--epochs", type=float, default=3)
    p.add_argument("--max-length", type=int, default=768)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--learning-rate", type=float, default=0.0002)
    args = p.parse_args()

    set_seed(args.seed)
    data_path = Path(args.data).resolve()
    output_dir = Path(args.output_dir).resolve()
    if not data_path.is_file():
        raise SystemExit(f"Dataset not found: {data_path}")
    rows = []
    with data_path.open(encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if line.strip():
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError as exc:
                    raise SystemExit(f"Invalid JSON on line {line_no}: {exc}")
    validation_path = Path(args.validation_data).resolve() if args.validation_data else None
    if validation_path and validation_path.is_file():
        val_rows = []
        with validation_path.open(encoding="utf-8") as f:
            for line_no, line in enumerate(f, 1):
                if line.strip():
                    try:
                        val_rows.append(json.loads(line))
                    except json.JSONDecodeError as exc:
                        raise SystemExit(f"Invalid JSON in validation line {line_no}: {exc}")
        train_rows = rows
    else:
        if len(rows) < 10:
            raise SystemExit("Use at least 10 clean examples; the included starter set has more.")
        random.Random(args.seed).shuffle(rows)
        val_count = max(1, len(rows) // 10)
        val_rows, train_rows = rows[:val_count], rows[val_count:]
    if not val_rows or not train_rows:
        raise SystemExit("Both training and validation sets must contain examples.")

    print(f"Base: {args.base_model}")
    print(f"Examples: {len(train_rows)} train / {len(val_rows)} validation")
    print("First run downloads the public base model; an internet connection is needed once.")
    tokenizer = AutoTokenizer.from_pretrained(args.base_model, use_fast=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    cuda = torch.cuda.is_available()
    dtype = torch.float16 if cuda else torch.float32
    model = AutoModelForCausalLM.from_pretrained(
        args.base_model, torch_dtype=dtype, low_cpu_mem_usage=True
    )
    model.config.use_cache = False
    lora = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=8,
        lora_alpha=16,
        lora_dropout=0.05,
        bias="none",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()

    train_ds = ChatDataset(train_rows, tokenizer, args.max_length)
    val_ds = ChatDataset(val_rows, tokenizer, args.max_length)
    output_dir.mkdir(parents=True, exist_ok=True)
    training_args = TrainingArguments(
        output_dir=str(output_dir / "checkpoints"),
        num_train_epochs=args.epochs,
        learning_rate=args.learning_rate,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=8,
        warmup_ratio=0.05,
        weight_decay=0.01,
        logging_steps=5,
        save_strategy="epoch",
        save_total_limit=1,
        fp16=cuda,
        report_to="none",
        remove_unused_columns=False,
        dataloader_pin_memory=cuda,
        optim="adamw_torch",
        seed=args.seed,
    )
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        data_collator=PadCollator(tokenizer.pad_token_id),
    )
    trainer.train()
    metrics = trainer.evaluate(eval_dataset=val_ds)
    model.save_pretrained(output_dir)
    tokenizer.save_pretrained(output_dir)
    (output_dir / "nano-training-info.json").write_text(json.dumps({
        "display_name": "Nano Local 0.1",
        "base_model": args.base_model,
        "train_examples": len(train_ds),
        "validation_examples": len(val_ds),
        "epochs": args.epochs,
        "seed": args.seed,
        "validation_metrics": metrics,
        "notice": "LoRA fine-tune adapter, not a foundation model trained from scratch."
    }, indent=2), encoding="utf-8")
    print(f"\nFinished. Adapter saved to: {output_dir}")
    print(f"Validation metrics: {metrics}")
    print("Next: python server.py --adapter \"" + str(output_dir) + "\" --host 0.0.0.0 --port 8080")

if __name__ == "__main__":
    main()
