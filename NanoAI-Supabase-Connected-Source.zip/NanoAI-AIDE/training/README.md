# Optional PC fine-tuning (not required for the app’s offline mode)

This folder retains an optional PC-based LoRA fine-tuning script and server. Nano AI’s default On-device Offline Brain does not use this server. You do not need to follow these instructions to use Nano AI offline. It is a starter, not a fully trained foundation model. It fine-tunes the public `Qwen/Qwen2.5-0.5B-Instruct` checkpoint into a Nano-specific adapter. The base model download requires internet once; inference after download can run locally. No Groq/Mistral API key is used.

## What this training teaches

The examples focus on Nano's voice, honest error reporting, local-server setup, click planning, dashboard/browser interaction intent, and refusing to claim unverified actions. The app's actual browser execution still comes from its JavaScript/Android tools; training examples alone cannot make a click happen. This starter is **text-only**. Live screenshot reasoning needs a vision-language model and compatible image-input server.

## Requirements for the optional PC experiment

Use a PC or laptop with Python 3.10 or 3.11, internet for the first model download, and preferably a GPU. Qwen 0.5B is small by LLM standards, but training still needs several GB of RAM/VRAM. Training on CPU can be very slow. A Galaxy Note 10+ is not a practical training host for this fine-tune.

## Windows setup

For a quick start on Windows, double-click `train_windows.bat`; it creates a virtual environment, installs dependencies, and starts training. When training finishes, run `run_server_windows.bat` to serve the adapter. These scripts require Python 3.11 and an internet connection for setup/model download.

Open a terminal in this `training` folder:

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python train.py --epochs 3
```

On Linux/macOS, use `python3 -m venv .venv`, activate with `source .venv/bin/activate`, then run the same `pip` and `python train.py` commands.

Training outputs the adapter and tokenizer to `training/output/nano-local-0.1/` by default. The script uses the included fixed `nano_validation.jsonl` so you can compare iterations on the same validation examples, masks the user's prompt from training loss, saves the LoRA adapter, and reports validation loss. If you intentionally want a fresh seeded split, run `python train.py --validation-data ""`. You can edit `nano_training.jsonl` to add your own examples (one JSON object per line, each with system/user/assistant messages). Keep a backup and never include API keys, passwords, private pages, or personal data in the dataset. Add examples you own or have permission to use.

## Start your model server

After training, from this `training` folder:

```bat
python server.py --adapter output/nano-local-0.1 --host 0.0.0.0 --port 8080
```

Test `http://127.0.0.1:8080/health` and `http://127.0.0.1:8080/v1/models` on the computer. This server provides `/v1/models` and streaming/non-streaming `/v1/chat/completions` for Nano Ai.

## Connect the Android app

1. Find your PC's LAN IPv4 address (for example `192.168.1.20`).
2. Keep the PC server running and allow port 8080 on your private-network firewall.
3. In Nano Ai, open **Account → AI key → Local AI (no API key)**.
4. Set the URL to `http://YOUR-PC-LAN-IP:8080/v1` and model name to `nano-local-0.1`, then save.
5. Ensure the phone and PC are on the same trusted Wi-Fi. `127.0.0.1` from Android points to the phone, not your PC.

## Security and limitations

The development server has no authentication and allows CORS for local WebView testing. **Do not expose port 8080 to the public internet or port-forward it.** Use it only on a trusted private network; add authentication/firewall controls before broader use. The server intentionally rejects image-input requests because this fine-tune is text-only. Use a separate vision-language checkpoint for live screenshot analysis.

This is fine-tuning of a public base model, not training a general LLM from scratch. The resulting adapter will not magically gain reliable tool execution or broad new knowledge from 96 examples. Add reviewed examples, evaluate on unseen prompts, and retrain in small iterations.
