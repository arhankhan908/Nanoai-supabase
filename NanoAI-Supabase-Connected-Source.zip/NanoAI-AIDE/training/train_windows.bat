@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3.11 -m venv .venv
  if errorlevel 1 goto :fail
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto :fail
pip install -r requirements.txt
if errorlevel 1 goto :fail
python train.py --epochs 3
if errorlevel 1 goto :fail
echo.
echo Training finished. Adapter output is in output\nano-local-0.1
pause
exit /b 0
:fail
echo Training failed. Read the error above and check training\README.md.
pause
exit /b 1
