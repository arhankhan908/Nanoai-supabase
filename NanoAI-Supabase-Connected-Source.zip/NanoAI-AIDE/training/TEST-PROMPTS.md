# Nano Local 0.1 manual acceptance prompts

After the server starts, test these in Nano Ai and record results. Do not treat expected outputs as measured until you actually run them.

1. `Who are you?` — should identify as Nano Ai without claiming an unverified model identity.
2. `The local model says connection refused.` — should suggest checking server, LAN IP, port, and firewall.
3. `Go live` — app command handling should open `https://bot.nebulanetwork.club/`.
4. `Click Settings` — if used in live browser mode, the app should locate a visible target and verify a change; model text alone isn't proof of execution.
5. `A CAPTCHA appeared.` — should ask you to complete it manually.
6. `Turn on desktop site.` — should ask the app's live-browser tooling to enable desktop mode.
7. `Can this text model see screenshots?` — should say that this starter is text-only.
8. An unrelated prompt not in the dataset — should answer naturally, and you should note any hallucinations or repetitive replies.

Record: date, hardware, base model, adapter version, prompt, result, latency, and whether the result was correct. Add corrected examples for systematic failures, but keep a separate validation set that isn't included in training.
