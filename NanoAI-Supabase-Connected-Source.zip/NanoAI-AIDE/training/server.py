#!/usr/bin/env python3
"""Local OpenAI-compatible server for the fine-tuned Nano LoRA adapter.

This is unauthenticated by design for private-LAN development only. Do not
expose this port to the public internet. The starter model is text-only.
"""
import argparse
import json
import os
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import torch
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from peft import AutoPeftModelForCausalLM
from transformers import AutoTokenizer, TextIteratorStreamer
from threading import Thread, Lock

p = argparse.ArgumentParser()
p.add_argument("--adapter", default=os.environ.get("NANO_ADAPTER_PATH", "output/nano-local-0.1"))
p.add_argument("--host", default="0.0.0.0")
p.add_argument("--port", type=int, default=8080)
ARGS = p.parse_args()
ADAPTER = Path(ARGS.adapter).expanduser().resolve()
MODEL_ID = "nano-local-0.1"
app = FastAPI(title="Nano Local Model Server", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
model = None
tokenizer = None
generation_lock = Lock()

@app.on_event("startup")
def load_model():
    global model, tokenizer
    if not (ADAPTER / "adapter_config.json").is_file():
        raise RuntimeError(f"LoRA adapter not found at {ADAPTER}. Run train.py first.")
    tokenizer = AutoTokenizer.from_pretrained(ADAPTER, use_fast=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    use_cuda = torch.cuda.is_available()
    dtype = torch.float16 if use_cuda else torch.float32
    model = AutoPeftModelForCausalLM.from_pretrained(
        ADAPTER,
        torch_dtype=dtype,
        device_map="auto" if use_cuda else None,
        low_cpu_mem_usage=True,
    )
    if not use_cuda:
        model.to("cpu")
    model.eval()
    print(f"Loaded {MODEL_ID} from {ADAPTER} ({'CUDA' if use_cuda else 'CPU'})")

@app.get("/health")
def health():
    return {"ok": model is not None, "model": MODEL_ID, "vision": False}

@app.get("/v1/models")
def list_models():
    return {"object": "list", "data": [{"id": MODEL_ID, "object": "model", "created": int(time.time()), "owned_by": "local-user"}]}

def parse_messages(messages):
    if not isinstance(messages, list) or not messages:
        raise HTTPException(400, detail={"error": {"message": "messages must be a non-empty array"}})
    clean = []
    for item in messages:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        if role not in ("system", "user", "assistant"):
            continue
        content = item.get("content", "")
        if isinstance(content, list):
            if any(isinstance(part, dict) and part.get("type") in ("image_url", "image") for part in content):
                raise HTTPException(400, detail={"error": {"message": "Nano Local 0.1 starter model is text-only; image input requires a vision-language model."}})
            content = "\n".join(str(part.get("text", "")) for part in content if isinstance(part, dict))
        if not isinstance(content, str):
            content = str(content)
        clean.append({"role": role, "content": content})
    if not clean:
        raise HTTPException(400, detail={"error": {"message": "No supported chat messages were provided."}})
    return clean

def prepare_input(messages):
    try:
        text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    except Exception as exc:
        raise HTTPException(400, detail={"error": {"message": f"Could not format chat: {exc}"}})
    inputs = tokenizer(text, return_tensors="pt")
    device = next(model.parameters()).device
    return {key: value.to(device) for key, value in inputs.items()}

def generation_options(body):
    max_new = int(body.get("max_completion_tokens", body.get("max_tokens", 500)) or 500)
    max_new = max(1, min(max_new, 1024))
    temperature = float(body.get("temperature", 0.4) or 0.0)
    options = {"max_new_tokens": max_new, "pad_token_id": tokenizer.pad_token_id, "eos_token_id": tokenizer.eos_token_id, "repetition_penalty": 1.05}
    if temperature > 0:
        options.update({"do_sample": True, "temperature": max(0.05, min(temperature, 1.5)), "top_p": 0.9})
    else:
        options["do_sample"] = False
    return options

def response_id():
    return "chatcmpl-" + uuid.uuid4().hex[:20]

def chunk_payload(cid, model_id, content=None, finish=None):
    delta = {"content": content} if content is not None else {}
    return {"id": cid, "object": "chat.completion.chunk", "created": int(time.time()), "model": model_id,
            "choices": [{"index": 0, "delta": delta, "finish_reason": finish}]}

@app.post("/v1/chat/completions")
def chat_completions(body: dict):
    if model is None or tokenizer is None:
        raise HTTPException(503, detail={"error": {"message": "Model has not loaded yet."}})
    messages = parse_messages(body.get("messages"))
    inputs = prepare_input(messages)
    options = generation_options(body)
    cid = response_id()
    requested_model = str(body.get("model") or MODEL_ID)
    if body.get("stream", False):
        streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True, timeout=180)
        def token_job():
            with torch.inference_mode():
                model.generate(**inputs, **options, streamer=streamer)
        def generate_sse():
            generation_lock.acquire()
            worker = Thread(target=token_job, daemon=True)
            try:
                worker.start()
                for piece in streamer:
                    if piece:
                        yield "data: " + json.dumps(chunk_payload(cid, MODEL_ID, content=piece), ensure_ascii=False) + "\n\n"
                worker.join()
                yield "data: " + json.dumps(chunk_payload(cid, MODEL_ID, finish="stop")) + "\n\n"
                yield "data: [DONE]\n\n"
            except Exception as exc:
                yield "data: " + json.dumps({"error": {"message": str(exc)}}) + "\n\n"
                yield "data: [DONE]\n\n"
            finally:
                if worker.is_alive():
                    worker.join()
                generation_lock.release()
        return StreamingResponse(generate_sse(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    with generation_lock, torch.inference_mode():
        outputs = model.generate(**inputs, **options)
    input_len = inputs["input_ids"].shape[-1]
    answer = tokenizer.decode(outputs[0][input_len:], skip_special_tokens=True)
    return JSONResponse({"id": cid, "object": "chat.completion", "created": int(time.time()), "model": MODEL_ID,
                         "choices": [{"index": 0, "message": {"role": "assistant", "content": answer}, "finish_reason": "stop"}],
                         "usage": {"prompt_tokens": input_len, "completion_tokens": int(outputs.shape[-1] - input_len), "total_tokens": int(outputs.shape[-1])}})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=ARGS.host, port=ARGS.port)
