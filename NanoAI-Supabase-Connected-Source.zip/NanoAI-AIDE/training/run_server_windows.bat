@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo No virtual environment. Run train_windows.bat first, or install requirements.txt.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
python server.py --adapter output/nano-local-0.1 --host 0.0.0.0 --port 8080
pause
