# Nano AI Live Vision — Test Report

Date: 2026-10-27

## Source changes present

- Visible browser capture uses Android `PixelCopy` on API 26+ and a latest-only JPEG cache. Copy, encoding, JS delivery, network requests and model calls are asynchronous; the UI has no per-frame network call.
- Capture target is configurable from 1 to 15 FPS and auto-throttles after sustained dropped/slow frames. Reported capture FPS comes from successful encoded frames, separate from AI request rate.
- The live HUD reports capture FPS/limit, AI analyses per second, age of the newest cached frame, last request latency, and cumulative dropped/stale frames.
- Vision messages contain both DOM/text and an image data URL. Provider model selection checks live model lists; it errors explicitly when vision support cannot be verified.
- Clicks get an on-page marker and are verified using a post-action DOM state snapshot (with a fresh screenshot requested for verification); unverifiable clicks are not labelled successful. Agent responses are discarded if the inspected page state changes while the model is reasoning.
- CAPTCHA/anti-bot and authentication/security challenge detection stops both fixed commands and agent actions. Closing or backgrounding the app stops further agent actions; navigation invalidates old cached frames.
- Embedded account credentials were removed from the shipped config. No API key is printed by the new frame pipeline.

## Checks actually run in this environment

- `node --check assets/live.js`: PASS
- `node --check assets/app.js`: PASS
- `node --check assets/auth.js`: PASS
- `node --check backend/netlify/functions/chat.mjs`: PASS
- Source grep for the previously hard-coded sample email/password: PASS (no matches after packaging).
- Android build: NOT RUN. The provided AIDE project has no Gradle wrapper/build files and this environment has no Android SDK (`android.jar`) configured.
- Target-device/runtime tests: NOT RUN. No connected Galaxy Note 10+ / Android 12 device is available in this environment.

## Required target-device verification (not yet measured)

1. Build and launch through AIDE on the target Android device.
2. Start live browser on a benign public page; confirm the actual website remains visible and telemetry updates.
3. Test capture limits 1, 5, 10 and 15 FPS. Record measured capture FPS, AI analysis rate, frame age, request latency and drops under Wi-Fi/mobile data.
4. Type and scroll continuously while capture runs; verify input responsiveness and inspect memory after a 10-minute session.
5. Test a public page with a safe button and a link; verify marker placement, page-state change detection, and unverified-click messaging.
6. Confirm CAPTCHA and 2FA test pages cause a stop without further automation. Do not use real credentials during the test.
7. Navigate/reload/close/background the app; verify stale frames are discarded and capture resumes only when the live browser is visible.
8. Verify an account with no vision-capable model produces the visible error and never silently switches to a text model.

No FPS, memory or latency result is claimed until these device tests are run.
